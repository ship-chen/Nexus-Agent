"""
Nexus Agent v3.0 — customtkinter 本地 GUI
Windows 11 风格，圆角、阴影、现代配色
"""

import customtkinter as ctk
import tkinter as tk
from tkinter import messagebox
import threading
import sys
import os
from datetime import datetime

if getattr(sys, 'frozen', False):
    BASE = os.path.dirname(sys.executable)
else:
    BASE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE)

# ── 主题 ──
ctk.set_appearance_mode("light")
ctk.set_default_color_theme("blue")

# ── 色彩 ──
C = {
    "primary": "#6366f1", "primary_h": "#4f46e5",
    "primary_light": "#eef2ff",
    "bg": "#f8fafc", "bg_card": "#ffffff", "bg_sidebar": "#ffffff",
    "bg_hover": "#f1f5f9", "bg_input": "#ffffff",
    "txt": "#0f172a", "txt2": "#475569", "txt3": "#94a3b8",
    "success": "#10b981", "warning": "#f59e0b", "error": "#ef4444",
    "purple": "#8b5cf6", "teal": "#14b8a6",
    "border": "#e2e8f0",
}


class NexusGUI(ctk.CTk):
    """Nexus Agent 本地 GUI"""

    def __init__(self):
        super().__init__()

        self.title("⚡ Nexus Agent v3.0")
        self.geometry("1280x820")
        self.minsize(1000, 600)

        # 初始化引擎
        from nexus.engine import Engine
        self.engine = Engine(os.path.join(BASE, "data"))

        # 界面状态
        self._panels = {}
        self._current = None

        self._build_sidebar()
        self._build_content()
        self._build_panels()

        # 默认显示对话
        self._show("chat")

        # 首次运行
        if self.engine.config.is_first_run:
            self.after(500, self._show_wizard)

    def _build_sidebar(self):
        """侧边栏"""
        self.sidebar = ctk.CTkFrame(self, width=210, corner_radius=0,
                                   fg_color=C["bg_sidebar"],
                                   border_width=0)
        self.sidebar.pack(side="left", fill="y")
        self.sidebar.pack_propagate(False)

        # Logo
        logo_frame = ctk.CTkFrame(self.sidebar, fg_color="transparent")
        logo_frame.pack(fill="x", padx=16, pady=(16, 8))
        ctk.CTkLabel(logo_frame, text="⚡", font=("", 28)).pack(side="left")
        ctk.CTkLabel(logo_frame, text="Nexus", font=("", 20, "bold"),
                    text_color=C["primary"]).pack(side="left", padx=(8, 0))
        ctk.CTkLabel(logo_frame, text="v3.0", font=("", 10),
                    text_color=C["txt3"]).pack(side="right")

        # 分割线
        ctk.CTkFrame(self.sidebar, height=1, fg_color=C["border"]).pack(fill="x", padx=16, pady=8)

        # 导航项
        self._nav_buttons = {}
        nav_frame = ctk.CTkFrame(self.sidebar, fg_color="transparent")
        nav_frame.pack(fill="both", expand=True, padx=8, pady=4)

        items = [
            ("chat",      "💬", "对话"),
            ("providers", "🔗", "API 提供商"),
            ("tools",     "🔧", "工具箱"),
            ("skills",    "🧩", "技能管理"),
            ("mcp",       "🔌", "MCP 服务"),
            ("gateway",   "📡", "消息网关"),
            ("memory",    "🧠", "记忆中心"),
            ("evolution", "🧬", "自进化"),
            ("voice",     "🔊", "语音"),
            ("terminal",  "⌨️", "终端"),
            ("notes",     "📝", "笔记"),
        ]

        for key, icon, label in items:
            btn = ctk.CTkButton(
                nav_frame, text=f" {icon}  {label}", anchor="w",
                font=("", 13), height=38, corner_radius=8,
                fg_color="transparent", text_color=C["txt"],
                hover_color=C["bg_hover"],
                command=lambda k=key: self._show(k)
            )
            btn.pack(fill="x", pady=1)
            self._nav_buttons[key] = btn

        # 底部设置
        ctk.CTkFrame(self.sidebar, height=1, fg_color=C["border"]).pack(fill="x", padx=16, pady=8)
        settings_btn = ctk.CTkButton(
            self.sidebar, text=" ⚙️  设置", anchor="w",
            font=("", 13), height=38, corner_radius=8,
            fg_color="transparent", text_color=C["txt"],
            hover_color=C["bg_hover"],
            command=lambda: self._show("settings")
        )
        settings_btn.pack(fill="x", padx=8, pady=(0, 12))
        self._nav_buttons["settings"] = settings_btn

    def _build_content(self):
        """内容区"""
        self.content = ctk.CTkFrame(self, fg_color=C["bg"], corner_radius=0)
        self.content.pack(side="left", fill="both", expand=True)

    def _build_panels(self):
        """构建所有面板"""
        self._panels["chat"] = ChatPanel(self.content, self.engine)
        self._panels["providers"] = ProvidersPanel(self.content, self.engine)
        self._panels["tools"] = ToolsPanel(self.content, self.engine)
        self._panels["skills"] = SkillsPanel(self.content, self.engine)
        self._panels["mcp"] = MCPPanel(self.content, self.engine)
        self._panels["gateway"] = GatewayPanel(self.content, self.engine)
        self._panels["memory"] = MemoryPanel(self.content, self.engine)
        self._panels["evolution"] = EvolutionPanel(self.content, self.engine)
        self._panels["voice"] = VoicePanel(self.content, self.engine)
        self._panels["terminal"] = TerminalPanel(self.content, self.engine)
        self._panels["notes"] = NotesPanel(self.content, self.engine)
        self._panels["settings"] = SettingsPanel(self.content, self.engine)

    def _show(self, key):
        """切换面板"""
        if self._current:
            self._current.pack_forget()
        panel = self._panels.get(key)
        if panel:
            panel.pack(fill="both", expand=True)
            self._current = panel
        # 高亮导航
        for k, btn in self._nav_buttons.items():
            if k == key:
                btn.configure(fg_color=C["primary_light"], text_color=C["primary"])
            else:
                btn.configure(fg_color="transparent", text_color=C["txt"])

    def _show_wizard(self):
        """设置向导"""
        WizardDialog(self, self.engine, self._panels)


# ══════════════════════════════════════
#  设置向导
# ══════════════════════════════════════

class WizardDialog(ctk.CTkToplevel):
    def __init__(self, parent, engine, panels):
        super().__init__(parent)
        self.engine = engine
        self.panels = panels
        self.title("⚡ 快速设置")
        self.geometry("580x480")
        self.resizable(False, False)
        self.transient(parent)
        self.grab_set()
        self._step = 0
        self._selected = None
        self._entries = {}
        self._build()

    def _build(self):
        for w in self.winfo_children():
            w.destroy()

        if self._step == 0:
            self._step_welcome()
        elif self._step == 1:
            self._step_select()
        elif self._step == 2:
            self._step_config()
        elif self._step == 3:
            self._step_done()

    def _step_welcome(self):
        f = ctk.CTkFrame(self, fg_color=C["bg"])
        f.pack(fill="both", expand=True)
        ctk.CTkLabel(f, text="⚡", font=("", 56)).pack(pady=(40, 12))
        ctk.CTkLabel(f, text="欢迎使用 Nexus Agent", font=("", 22, "bold")).pack()
        ctk.CTkLabel(f, text="通用 AI 智能体平台\n融合 OpenClaw × Hermes Agent",
                    font=("", 13), text_color=C["txt2"]).pack(pady=8)
        ctk.CTkLabel(f, text="只需 3 步：选提供商 → 填 API Key → 开始对话",
                    font=("", 12), text_color=C["txt3"]).pack(pady=4)
        ctk.CTkButton(f, text="开始设置 →", font=("", 14, "bold"),
                     width=200, height=44, corner_radius=10,
                     command=self._next).pack(pady=24)

    def _step_select(self):
        from nexus.providers import PROVIDERS, get_by_region
        f = ctk.CTkFrame(self, fg_color=C["bg"])
        f.pack(fill="both", expand=True, padx=20, pady=16)
        ctk.CTkLabel(f, text="选择 AI 提供商", font=("", 18, "bold")).pack(anchor="w")
        ctk.CTkLabel(f, text="国内提供商无需翻墙，开箱即用",
                    font=("", 11), text_color=C["txt3"]).pack(anchor="w", pady=(0, 8))

        scroll = ctk.CTkScrollableFrame(f, fg_color=C["bg"])
        scroll.pack(fill="both", expand=True)

        grouped = get_by_region()
        for region, label in [("cn", "🇨🇳 国内"), ("local", "💻 本地"), ("intl", "🌍 国际")]:
            ps = grouped[region]
            if not ps:
                continue
            ctk.CTkLabel(scroll, text=label, font=("", 13, "bold")).pack(anchor="w", pady=(8, 4))
            grid = ctk.CTkFrame(scroll, fg_color="transparent")
            grid.pack(fill="x")
            for i, p in enumerate(ps):
                row, col = divmod(i, 3)
                card = ctk.CTkButton(
                    grid, text=f"{p['icon']} {p['name']}\n{p['desc'][:20]}",
                    font=("", 11), width=170, height=60, corner_radius=10,
                    anchor="w", fg_color=C["bg_card"],
                    hover_color=C["primary_light"],
                    text_color=C["txt"],
                    command=lambda pid=p["id"]: self._select(pid)
                )
                card.grid(row=row, column=col, padx=4, pady=4, sticky="nsew")
            grid.grid_columnconfigure((0, 1, 2), weight=1)

        ctk.CTkButton(f, text="← 返回", font=("", 12), width=80, height=32,
                     fg_color="transparent", text_color=C["txt2"],
                     hover_color=C["bg_hover"],
                     command=self._back).pack(anchor="w", pady=(8, 0))

    def _select(self, pid):
        self._selected = pid
        self._next()

    def _step_config(self):
        from nexus.providers import PROVIDERS
        p = PROVIDERS.get(self._selected, {})
        f = ctk.CTkFrame(self, fg_color=C["bg"])
        f.pack(fill="both", expand=True, padx=20, pady=16)

        ctk.CTkLabel(f, text=f"{p.get('icon', '')} {p.get('name', '')}",
                    font=("", 18, "bold")).pack(anchor="w")
        ctk.CTkLabel(f, text=p.get("desc", ""),
                    font=("", 11), text_color=C["txt3"]).pack(anchor="w", pady=(0, 12))

        form = ctk.CTkFrame(f, fg_color=C["bg_card"], corner_radius=12)
        form.pack(fill="x")
        self._entries = {}

        if p.get("needs_key", True):
            self._field(form, "api_key", "API Key", "sk-xxx", show="•")
        self._field(form, "base_url", "API 地址", p.get("base_url", ""))
        self._field(form, "default_model", "默认模型", p.get("default", ""))

        ctk.CTkLabel(form, text=f"可用: {', '.join(p.get('models', [])[:4])}",
                    font=("", 10), text_color=C["txt3"]).pack(anchor="w", padx=16, pady=(0, 12))

        bf = ctk.CTkFrame(f, fg_color="transparent")
        bf.pack(fill="x", pady=12)
        ctk.CTkButton(bf, text="← 返回", width=80, height=36, fg_color="transparent",
                     text_color=C["txt2"], hover_color=C["bg_hover"],
                     command=self._back).pack(side="left")
        ctk.CTkButton(bf, text="🔌 测试连接", width=120, height=36,
                     fg_color=C["bg_hover"], hover_color="#cbd5e1",
                     text_color=C["txt"],
                     command=self._test).pack(side="left", padx=8)
        ctk.CTkButton(bf, text="✅ 保存并开始 →", width=160, height=36,
                     corner_radius=8,
                     command=self._save).pack(side="right")

        self._status = ctk.CTkLabel(f, text="", font=("", 12))
        self._status.pack(anchor="w")

    def _field(self, parent, key, label, placeholder, **kw):
        r = ctk.CTkFrame(parent, fg_color="transparent")
        r.pack(fill="x", padx=16, pady=6)
        ctk.CTkLabel(r, text=label, font=("", 12, "bold"), width=100,
                    anchor="w").pack(side="left")
        e = ctk.CTkEntry(r, placeholder_text=placeholder, font=("", 12),
                        height=36, corner_radius=8, **kw)
        e.pack(side="left", fill="x", expand=True)
        self._entries[key] = e

    def _test(self):
        cfg = self._get_cfg()
        self._status.configure(text="⏳ 测试中...", text_color=C["warning"])
        def do():
            from nexus.ai_client import test_connection
            r = test_connection(cfg)
            self.after(0, lambda: self._status.configure(
                text=f"✅ 连接成功" if r["ok"] else f"❌ {r['error'][:60]}",
                text_color=C["success"] if r["ok"] else C["error"]
            ))
        threading.Thread(target=do, daemon=True).start()

    def _get_cfg(self):
        cfg = {}
        for k, e in self._entries.items():
            v = e.get().strip()
            if v:
                cfg[k] = v
        return cfg

    def _save(self):
        cfg = self._get_cfg()
        pid = self._selected
        self.engine.config.set(f"providers.{pid}", cfg)
        self.engine.config.data["active_provider"] = pid
        self.engine.config.data["active_model"] = cfg.get("default_model", cfg.get("default", ""))
        self.engine.config.mark_configured()
        self._next()

    def _step_done(self):
        f = ctk.CTkFrame(self, fg_color=C["bg"])
        f.pack(fill="both", expand=True)
        ctk.CTkLabel(f, text="✅", font=("", 56)).pack(pady=(50, 12))
        ctk.CTkLabel(f, text="设置完成！", font=("", 22, "bold"),
                    text_color=C["success"]).pack()
        ctk.CTkLabel(f, text="点击下方按钮开始对话", font=("", 12),
                    text_color=C["txt3"]).pack(pady=8)
        ctk.CTkButton(f, text="🚀 开始使用", width=180, height=44,
                     corner_radius=10,
                     command=self.destroy).pack(pady=24)

    def _next(self):
        self._step += 1
        self._build()

    def _back(self):
        self._step = max(0, self._step - 1)
        self._build()


# ══════════════════════════════════════
#  对话面板
# ══════════════════════════════════════

class ChatPanel(ctk.CTkFrame):
    def __init__(self, parent, engine):
        super().__init__(parent, fg_color=C["bg"])
        self.engine = engine

        # 头部
        hd = ctk.CTkFrame(self, height=48, fg_color=C["bg_card"], corner_radius=0)
        hd.pack(fill="x")
        ctk.CTkLabel(hd, text="💬 对话", font=("", 16, "bold")).pack(side="left", padx=16)
        self._model_lbl = ctk.CTkLabel(hd, text="", font=("", 11), text_color=C["txt3"])
        self._model_lbl.pack(side="left", padx=8)
        ctk.CTkButton(hd, text="✦ 新对话", font=("", 11), width=80, height=28,
                     fg_color="transparent", text_color=C["primary"],
                     hover_color=C["primary_light"],
                     command=self._new).pack(side="right", padx=16)
        self._update_model()

        # 消息区
        self._msg_frame = ctk.CTkScrollableFrame(self, fg_color=C["bg"])
        self._msg_frame.pack(fill="both", expand=True, padx=0, pady=0)

        # 欢迎
        self._welcome()

        # 输入区
        inp = ctk.CTkFrame(self, fg_color=C["bg_card"], corner_radius=0, height=60)
        inp.pack(fill="x", side="bottom")
        row = ctk.CTkFrame(inp, fg_color="transparent")
        row.pack(fill="x", padx=16, pady=10)
        self._input = ctk.CTkEntry(row, placeholder_text="输入消息... (Enter 发送)",
                                   font=("", 13), height=42, corner_radius=21)
        self._input.pack(side="left", fill="x", expand=True, padx=(0, 8))
        self._input.bind("<Return>", lambda e: self._send())
        ctk.CTkButton(row, text="➤", width=42, height=42, corner_radius=21,
                     font=("", 18), command=self._send).pack(side="right")
        ctk.CTkLabel(inp, text="⚡ Nexus Agent · 工具调用 · 自进化学习 · 持久记忆",
                    font=("", 10), text_color=C["txt3"]).pack(pady=(0, 6))

    def _update_model(self):
        pid = self.engine.config.data.get("active_provider", "")
        mdl = self.engine.config.data.get("active_model", "")
        if pid and mdl:
            self._model_lbl.configure(text=f"{pid} / {mdl}")
        else:
            self._model_lbl.configure(text="⚠️ 未配置")

    def _welcome(self):
        f = ctk.CTkFrame(self._msg_frame, fg_color="transparent")
        f.pack(fill="x", pady=60)
        ctk.CTkLabel(f, text="⚡", font=("", 48)).pack()
        ctk.CTkLabel(f, text="欢迎使用 Nexus Agent", font=("", 20, "bold")).pack(pady=(12, 4))
        ctk.CTkLabel(f, text="输入任意问题开始对话",
                    font=("", 12), text_color=C["txt2"]).pack()

    def _new(self):
        for w in self._msg_frame.winfo_children():
            w.destroy()
        self._welcome()
        self.engine.new_session()

    def _send(self):
        msg = self._input.get().strip()
        if not msg:
            return
        self._input.delete(0, "end")

        # 清欢迎
        children = self._msg_frame.winfo_children()
        if len(children) <= 2:
            for w in children:
                w.destroy()

        # 用户气泡
        self._add_bubble(msg, True)

        # 思考指示
        self._thinking = ctk.CTkLabel(self._msg_frame, text="💭 思考中...",
                                      font=("", 12), text_color=C["warning"])
        self._thinking.pack(anchor="w", padx=16, pady=4)

        def do():
            r = self.engine.chat(msg)
            self.after(0, lambda: self._on_reply(r))

        threading.Thread(target=do, daemon=True).start()

    def _on_reply(self, r):
        self._thinking.destroy()
        self._add_bubble(r.get("text", r.get("error", "无回复")), False)

        extras = []
        if r.get("learned"):
            extras.append("🧬 已学习")
        if r.get("tool_used"):
            extras.append("🔧 调用了工具")
        if r.get("memories_used"):
            extras.append(f"🧠 {r['memories_used']}条记忆")
        if extras:
            ctk.CTkLabel(self._msg_frame, text="  ".join(extras),
                        font=("", 10), text_color=C["purple"]).pack(anchor="w", padx=16, pady=2)

    def _add_bubble(self, text, is_user):
        if is_user:
            bubble = ctk.CTkLabel(
                self._msg_frame, text=text, font=("", 13),
                fg_color=C["primary"], text_color="white",
                corner_radius=16, anchor="w", justify="left",
                wraplength=500, padx=14, pady=10
            )
            bubble.pack(anchor="e", padx=(80, 16), pady=4)
        else:
            bubble = ctk.CTkLabel(
                self._msg_frame, text=text, font=("", 13),
                fg_color=C["bg_card"], text_color=C["txt"],
                corner_radius=16, anchor="w", justify="left",
                wraplength=500, padx=14, pady=10,
                border_width=1, border_color=C["border"]
            )
            bubble.pack(anchor="w", padx=(16, 80), pady=4)


# ══════════════════════════════════════
#  通用面板基类
# ══════════════════════════════════════

class BasePanel(ctk.CTkFrame):
    """带标题栏的面板基类"""

    def __init__(self, parent, title, subtitle="", **kw):
        super().__init__(parent, fg_color=C["bg"], **kw)
        hd = ctk.CTkFrame(self, height=48, fg_color=C["bg_card"], corner_radius=0)
        hd.pack(fill="x")
        ctk.CTkLabel(hd, text=title, font=("", 16, "bold")).pack(side="left", padx=16)
        if subtitle:
            ctk.CTkLabel(hd, text=subtitle, font=("", 11),
                        text_color=C["txt3"]).pack(side="left")
        self.body = ctk.CTkScrollableFrame(self, fg_color=C["bg"])
        self.body.pack(fill="both", expand=True, padx=16, pady=16)

    def card(self, parent=None, **kw):
        p = parent or self.body
        return ctk.CTkFrame(p, fg_color=C["bg_card"], corner_radius=12,
                           border_width=1, border_color=C["border"], **kw)


# ══════════════════════════════════════
#  提供商面板
# ══════════════════════════════════════

class ProvidersPanel(BasePanel):
    def __init__(self, parent, engine):
        super().__init__(parent, "🔗 API 提供商", "18+ 预置 · 国内外全覆盖")
        self.engine = engine
        self._load()

    def _load(self):
        from nexus.providers import PROVIDERS, get_by_region
        grouped = get_by_region()
        active = self.engine.config.data.get("active_provider", "")

        for region, label in [("cn", "🇨🇳 国内"), ("local", "💻 本地"), ("intl", "🌍 国际")]:
            ps = grouped[region]
            if not ps:
                continue
            ctk.CTkLabel(self.body, text=label, font=("", 14, "bold")).pack(anchor="w", pady=(12, 6))
            grid = ctk.CTkFrame(self.body, fg_color="transparent")
            grid.pack(fill="x")
            for i, p in enumerate(ps):
                row, col = divmod(i, 3)
                is_active = p["id"] == active
                txt = f"{p['icon']} {p['name']}\n{p['desc'][:25]}"
                if is_active:
                    txt += "\n✅ 使用中"
                btn = ctk.CTkButton(
                    grid, text=txt, font=("", 11), width=200, height=65,
                    corner_radius=10, anchor="w",
                    fg_color=C["primary_light"] if is_active else C["bg_card"],
                    hover_color=C["primary_light"],
                    text_color=C["primary"] if is_active else C["txt"],
                    border_width=1, border_color=C["primary"] if is_active else C["border"],
                    command=lambda pid=p["id"]: self._select(pid)
                )
                btn.grid(row=row, column=col, padx=4, pady=4, sticky="nsew")
            grid.grid_columnconfigure((0, 1, 2), weight=1)

    def _select(self, pid):
        from nexus.providers import PROVIDERS
        p = PROVIDERS.get(pid, {})
        # 弹出配置对话
        dlg = ctk.CTkToplevel(self)
        dlg.title(f"{p.get('icon', '')} {p.get('name', '')}")
        dlg.geometry("450x350")
        dlg.transient(self.winfo_toplevel())
        dlg.grab_set()

        f = ctk.CTkFrame(dlg, fg_color=C["bg"])
        f.pack(fill="both", expand=True, padx=20, pady=16)
        ctk.CTkLabel(f, text=f"{p.get('icon', '')} {p.get('name', '')}",
                    font=("", 16, "bold")).pack(anchor="w")
        ctk.CTkLabel(f, text=p.get("desc", ""),
                    font=("", 11), text_color=C["txt3"]).pack(anchor="w", pady=(0, 12))

        entries = {}
        if p.get("needs_key", True):
            entries["api_key"] = self._dlg_field(f, "API Key", "sk-xxx", show="•")
        entries["base_url"] = self._dlg_field(f, "API 地址", p.get("base_url", ""))
        entries["default_model"] = self._dlg_field(f, "默认模型", p.get("default", ""))

        ctk.CTkLabel(f, text=f"可用: {', '.join(p.get('models', [])[:4])}",
                    font=("", 10), text_color=C["txt3"]).pack(anchor="w")

        bf = ctk.CTkFrame(f, fg_color="transparent")
        bf.pack(fill="x", pady=12)
        ctk.CTkButton(bf, text="✅ 保存", width=120, height=36,
                     command=lambda: self._save(pid, entries, dlg)).pack(side="right", padx=4)
        ctk.CTkButton(bf, text="🔌 测试", width=100, height=36,
                     fg_color=C["bg_hover"], text_color=C["txt"],
                     hover_color="#cbd5e1",
                     command=lambda: self._test(entries)).pack(side="right")

    def _dlg_field(self, parent, label, placeholder, **kw):
        r = ctk.CTkFrame(parent, fg_color="transparent")
        r.pack(fill="x", pady=4)
        ctk.CTkLabel(r, text=label, font=("", 12, "bold"), width=80).pack(side="left")
        e = ctk.CTkEntry(r, placeholder_text=placeholder, font=("", 12),
                        height=34, corner_radius=8, **kw)
        e.pack(side="left", fill="x", expand=True)
        return e

    def _save(self, pid, entries, dlg):
        cfg = {}
        for k, e in entries.items():
            v = e.get().strip()
            if v:
                cfg[k] = v
        self.engine.config.set(f"providers.{pid}", cfg)
        self.engine.config.data["active_provider"] = pid
        self.engine.config.data["active_model"] = cfg.get("default_model", cfg.get("default", ""))
        self.engine.config.mark_configured()
        dlg.destroy()
        messagebox.showinfo("保存成功", f"✅ 已启用 {pid}")

    def _test(self, entries):
        cfg = {}
        for k, e in entries.items():
            v = e.get().strip()
            if v:
                cfg[k] = v
        from nexus.ai_client import test_connection
        r = test_connection(cfg)
        messagebox.showinfo("测试结果", "✅ 连接成功" if r["ok"] else f"❌ {r['error'][:100]}")


# ══════════════════════════════════════
#  工具面板
# ══════════════════════════════════════

class ToolsPanel(BasePanel):
    def __init__(self, parent, engine):
        super().__init__(parent, "🔧 工具箱", "内置可执行工具")
        from nexus.tools import TOOLS
        grid = ctk.CTkFrame(self.body, fg_color="transparent")
        grid.pack(fill="x")
        for i, (k, t) in enumerate(TOOLS.items()):
            row, col = divmod(i, 3)
            card = ctk.CTkFrame(grid, fg_color=C["bg_card"], corner_radius=12,
                               border_width=1, border_color=C["border"])
            card.grid(row=row, column=col, padx=4, pady=4, sticky="nsew")
            ctk.CTkLabel(card, text=f"{t['icon']} {t['name']}",
                        font=("", 14, "bold")).pack(anchor="w", padx=12, pady=(12, 0))
            ctk.CTkLabel(card, text=t["desc"], font=("", 11),
                        text_color=C["txt2"], wraplength=200).pack(anchor="w", padx=12)
            params = ", ".join(t["params"]) if t["params"] else "无"
            ctk.CTkLabel(card, text=f"参数: {params}", font=("", 10),
                        text_color=C["txt3"]).pack(anchor="w", padx=12, pady=(0, 12))
        grid.grid_columnconfigure((0, 1, 2), weight=1)


# ══════════════════════════════════════
#  技能面板
# ══════════════════════════════════════

class SkillsPanel(BasePanel):
    def __init__(self, parent, engine):
        super().__init__(parent, "🧩 技能管理", "文件技能 + 自动学习")
        file_skills = engine.skills.list_skills()
        db_skills = engine.memory.get_skills()

        if file_skills:
            ctk.CTkLabel(self.body, text="📁 文件技能", font=("", 13, "bold")).pack(anchor="w", pady=(0, 6))
            for s in file_skills:
                card = self.card()
                card.pack(fill="x", pady=4)
                ctk.CTkLabel(card, text=f"📄 {s['name']}  {s['desc'][:40]}",
                            font=("", 12)).pack(anchor="w", padx=12, pady=8)

        if db_skills:
            ctk.CTkLabel(self.body, text="🧠 学习技能", font=("", 13, "bold")).pack(anchor="w", pady=(12, 6))
            for s in db_skills:
                card = self.card()
                card.pack(fill="x", pady=4)
                icon = "🧬" if s["auto"] else "🧩"
                ctk.CTkLabel(card, text=f"{icon} {s['name']}  使用 {s['uses']} 次",
                            font=("", 12)).pack(anchor="w", padx=12, pady=8)

        if not file_skills and not db_skills:
            ctk.CTkLabel(self.body, text="🧩 暂无技能\n\n技能会在对话中自动学习积累",
                        font=("", 13), text_color=C["txt3"]).pack(pady=60)


# ══════════════════════════════════════
#  其他面板（简洁实现）
# ══════════════════════════════════════

class MCPPanel(BasePanel):
    def __init__(self, parent, engine):
        super().__init__(parent, "🔌 MCP 服务", "Model Context Protocol")
        from nexus.mcp import PRESET_MCP_SERVERS
        for sid, cfg in PRESET_MCP_SERVERS.items():
            card = self.card()
            card.pack(fill="x", pady=4)
            ctk.CTkLabel(card, text=f"🔌 {cfg['name']}  —  {cfg['desc']}",
                        font=("", 12)).pack(anchor="w", padx=12, pady=8)

class GatewayPanel(BasePanel):
    def __init__(self, parent, engine):
        super().__init__(parent, "📡 消息网关", "Telegram · Discord · 飞书")
        grid = ctk.CTkFrame(self.body, fg_color="transparent")
        grid.pack(fill="x")
        for i, (k, ch) in enumerate(engine.gateway.CHANNELS.items()):
            row, col = divmod(i, 3)
            card = ctk.CTkFrame(grid, fg_color=C["bg_card"], corner_radius=12,
                               border_width=1, border_color=C["border"])
            card.grid(row=row, column=col, padx=4, pady=4, sticky="nsew")
            ctk.CTkLabel(card, text=f"{ch['icon']} {ch['name']}",
                        font=("", 14, "bold")).pack(anchor="w", padx=12, pady=(12, 0))
            ctk.CTkLabel(card, text=ch["desc"], font=("", 11),
                        text_color=C["txt2"]).pack(anchor="w", padx=12, pady=(0, 12))
        grid.grid_columnconfigure((0, 1, 2), weight=1)

class MemoryPanel(BasePanel):
    def __init__(self, parent, engine):
        super().__init__(parent, "🧠 记忆中心", "分层持久化记忆")
        stats = engine.memory.stats()
        row = ctk.CTkFrame(self.body, fg_color="transparent")
        row.pack(fill="x", pady=(0, 12))
        for lb, val, clr in [("记忆", stats["memories"], C["primary"]),
                              ("对话", stats["conversations"], C["teal"]),
                              ("技能", stats["skills"], C["purple"]),
                              ("进化", stats["evolutions"], C["success"])]:
            card = ctk.CTkFrame(row, fg_color=C["bg_card"], corner_radius=12,
                               border_width=1, border_color=C["border"])
            card.pack(side="left", fill="x", expand=True, padx=4)
            ctk.CTkLabel(card, text=str(val), font=("", 24, "bold"),
                        text_color=clr).pack(pady=(12, 0))
            ctk.CTkLabel(card, text=lb, font=("", 11),
                        text_color=C["txt2"]).pack(pady=(0, 12))

        mems = engine.memory.get_all_memories(limit=20)
        for m in mems:
            card = self.card()
            card.pack(fill="x", pady=3)
            ctk.CTkLabel(card, text=m["content"][:100], font=("", 12),
                        wraplength=500).pack(anchor="w", padx=12, pady=8)

class EvolutionPanel(BasePanel):
    def __init__(self, parent, engine):
        super().__init__(parent, "🧬 自进化系统", "Hermes Agent 核心能力")
        stages = [("🌱","初始"), ("🌿","学习中"), ("🌳","成长期"), ("⚡","成熟体"), ("🧬","进化体")]
        row = ctk.CTkFrame(self.body, fg_color="transparent")
        row.pack(fill="x", pady=(0, 16))
        for icon, name in stages:
            card = ctk.CTkFrame(row, fg_color=C["bg_card"], corner_radius=12,
                               border_width=1, border_color=C["border"])
            card.pack(side="left", fill="x", expand=True, padx=4)
            ctk.CTkLabel(card, text=icon, font=("", 28)).pack(pady=(12, 0))
            ctk.CTkLabel(card, text=name, font=("", 12, "bold")).pack(pady=(0, 12))

        evos = engine.memory.get_evolution()
        if evos:
            ctk.CTkLabel(self.body, text="📋 进化时间线", font=("", 13, "bold")).pack(anchor="w", pady=(0, 6))
            for e in evos[:10]:
                card = self.card()
                card.pack(fill="x", pady=3)
                ctk.CTkLabel(card, text=f"🧬 {e['event']}  {e.get('detail', '')[:50]}",
                            font=("", 12)).pack(anchor="w", padx=12, pady=8)

class VoicePanel(BasePanel):
    def __init__(self, parent, engine):
        super().__init__(parent, "🔊 语音系统", "TTS 文本转语音")
        ctk.CTkLabel(self.body, text=f"TTS 引擎: {engine.voice.tts_engine}",
                    font=("", 13, "bold")).pack(anchor="w")
        ctk.CTkLabel(self.body, text="推荐: pip install edge-tts",
                    font=("", 11), text_color=C["txt3"]).pack(anchor="w", pady=(0, 12))
        f = ctk.CTkFrame(self.body, fg_color="transparent")
        f.pack(fill="x")
        self._voice_input = ctk.CTkEntry(f, placeholder_text="输入要朗读的文字...",
                                         font=("", 12), height=36)
        self._voice_input.pack(side="left", fill="x", expand=True, padx=(0, 8))
        self._voice_input.insert(0, "你好，我是 Nexus Agent")
        ctk.CTkButton(f, text="🔊 朗读", width=80, height=36,
                     command=lambda: threading.Thread(
                         target=engine.voice.speak,
                         args=(self._voice_input.get(),), daemon=True
                     ).start()).pack(side="right")

class TerminalPanel(ctk.CTkFrame):
    def __init__(self, parent, engine):
        super().__init__(parent, fg_color="#1e1e1e")
        hd = ctk.CTkFrame(self, height=36, fg_color="#2d2d2d", corner_radius=0)
        hd.pack(fill="x")
        ctk.CTkLabel(hd, text=" ⌨️ 终端", font=("", 12, "bold"),
                    text_color="#ccc").pack(side="left", padx=12)
        self._out = ctk.CTkTextbox(self, font=("Cascadia Code", 13),
                                   fg_color="#1e1e1e", text_color="#d4d4d4",
                                   corner_radius=0)
        self._out.pack(fill="both", expand=True)
        self._insert("⚡ Nexus Agent 终端\n输入命令执行，clear 清屏\n" + "─" * 50 + "\n")
        inp_f = ctk.CTkFrame(self, fg_color="#1e1e1e", height=40)
        inp_f.pack(fill="x", padx=8, pady=8)
        ctk.CTkLabel(inp_f, text="❯", font=("Cascadia Code", 14),
                    text_color=C["primary"]).pack(side="left")
        self._cmd = ctk.CTkEntry(inp_f, font=("Cascadia Code", 13),
                                fg_color="#1e1e1e", text_color="#d4d4d4",
                                border_width=0, height=36)
        self._cmd.pack(side="left", fill="x", expand=True, padx=8)
        self._cmd.bind("<Return>", lambda e: self._run(engine))

    def _insert(self, t):
        self._out.configure(state="normal")
        self._out.insert("end", t)
        self._out.see("end")
        self._out.configure(state="disabled")

    def _run(self, engine):
        import subprocess
        cmd = self._cmd.get().strip()
        self._cmd.delete(0, "end")
        if not cmd:
            return
        self._insert(f"\n❯ {cmd}\n")
        if cmd == "clear":
            self._out.configure(state="normal")
            self._out.delete("1.0", "end")
            self._out.configure(state="disabled")
            return
        try:
            r = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=15)
            output = (r.stdout or "") + (r.stderr or "")
            self._insert(output.strip() or "(无输出)" + "\n")
        except Exception as e:
            self._insert(f"❌ {e}\n")

class NotesPanel(BasePanel):
    def __init__(self, parent, engine):
        super().__init__(parent, "📝 笔记", "AI 自动创建")
        notes = engine.memory.get_notes()
        if notes:
            for n in notes:
                card = self.card()
                card.pack(fill="x", pady=4)
                ctk.CTkLabel(card, text=n["title"], font=("", 13, "bold")).pack(anchor="w", padx=12, pady=(8, 0))
                ctk.CTkLabel(card, text=n["content"][:100], font=("", 11),
                            text_color=C["txt2"]).pack(anchor="w", padx=12, pady=(0, 8))
        else:
            ctk.CTkLabel(self.body, text="📝 暂无笔记\n在对话中告诉 AI「记个笔记」即可创建",
                        font=("", 13), text_color=C["txt3"]).pack(pady=60)

class SettingsPanel(BasePanel):
    def __init__(self, parent, engine):
        super().__init__(parent, "⚙️ 设置", "")
        pid = engine.config.data.get("active_provider", "")
        mdl = engine.config.data.get("active_model", "")
        card = self.card()
        card.pack(fill="x", pady=(0, 12))
        ctk.CTkLabel(card, text=f"🤖 当前模型: {pid or '未配置'} / {mdl or '未配置'}",
                    font=("", 13)).pack(anchor="w", padx=16, pady=12)

        stats = engine.memory.stats()
        card2 = self.card()
        card2.pack(fill="x", pady=(0, 12))
        ctk.CTkLabel(card2, text="📊 运行统计", font=("", 13, "bold")).pack(anchor="w", padx=16, pady=(12, 0))
        ctk.CTkLabel(card2, text=f"记忆: {stats['memories']}  对话: {stats['conversations']}  "
                                 f"技能: {stats['skills']}  进化: {stats['evolutions']}",
                    font=("", 12), text_color=C["txt2"]).pack(anchor="w", padx=16, pady=(0, 12))


# ── 启动 ──
def main():
    app = NexusGUI()
    app.mainloop()

if __name__ == "__main__":
    main()
