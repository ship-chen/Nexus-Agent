#!/usr/bin/env python3
"""Nexus v2.0 打包脚本"""
import subprocess, sys, os

def build(mode="dir"):
    subprocess.check_call([sys.executable, "-m", "pip", "install", "pyinstaller"])
    cmd = [
        sys.executable, "-m", "PyInstaller",
        "--name=NexusAgent", "--windowed",
        "--add-data=nexus;nexus",
        "--hidden-import=nexus.ui.theme",
        "--hidden-import=nexus.ui.widgets",
        "--clean", "main.py",
    ]
    if mode == "single":
        cmd.insert(5, "--onefile")
    else:
        cmd.insert(5, "--onedir")
    subprocess.check_call(cmd)
    print(f"\n✅ 完成: dist/NexusAgent{'/' if mode=='dir' else '.exe'}")

if __name__ == "__main__":
    import argparse
    p = argparse.ArgumentParser()
    p.add_argument("--single", action="store_true")
    args = p.parse_args()
    build("single" if args.single else "dir")
