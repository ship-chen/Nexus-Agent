"""
Nexus Agent v2.0 — 通用 AI 智能体平台
融合 OpenClaw × Hermes Agent 核心优势
开箱即用，输入 API Key 即可使用
"""

__version__ = "2.0.0"
__author__ = "Nexus Team"
