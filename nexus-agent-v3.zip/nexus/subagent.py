"""
Nexus v2.0 — 子代理系统
OpenClaw 风格的子代理编排
"""

import threading
import uuid
from datetime import datetime


class SubAgent:
    """单个子代理"""

    def __init__(self, name: str, task: str, engine):
        self.id = str(uuid.uuid4())[:8]
        self.name = name
        self.task = task
        self.engine = engine
        self.status = "pending"  # pending / running / done / error
        self.result = ""
        self.created = datetime.now().isoformat(timespec="seconds")
        self.finished = None
        self._thread = None
        self._history = []

    def run(self):
        """在后台线程中执行"""
        self.status = "running"
        self._thread = threading.Thread(target=self._execute, daemon=True)
        self._thread.start()

    def _execute(self):
        try:
            result = self.engine.chat(
                f"[子代理任务] {self.task}\n\n请专注完成这个任务，给出详细结果。"
            )
            self.result = result.get("text", "")
            self.status = "done"
        except Exception as e:
            self.result = f"错误: {e}"
            self.status = "error"
        self.finished = datetime.now().isoformat(timespec="seconds")


class SubAgentManager:
    """子代理管理器"""

    def __init__(self, engine):
        self.engine = engine
        self.agents: dict[str, SubAgent] = {}

    def spawn(self, name: str, task: str) -> str:
        """创建并启动子代理"""
        agent = SubAgent(name, task, self.engine)
        self.agents[agent.id] = agent
        agent.run()
        return agent.id

    def get(self, agent_id: str) -> SubAgent:
        return self.agents.get(agent_id)

    def list_all(self) -> list:
        return [
            {"id": a.id, "name": a.name, "task": a.task[:50],
             "status": a.status, "created": a.created}
            for a in sorted(self.agents.values(),
                          key=lambda x: x.created, reverse=True)
        ]

    def active_count(self) -> int:
        return sum(1 for a in self.agents.values() if a.status == "running")

    def kill(self, agent_id: str):
        """标记子代理为取消"""
        agent = self.agents.get(agent_id)
        if agent and agent.status == "running":
            agent.status = "error"
            agent.result = "已取消"
            agent.finished = datetime.now().isoformat(timespec="seconds")
