"""
Nexus v2.0 — AI 客户端
统一 API 调用层，支持 OpenAI/Anthropic/Ollama 及所有兼容格式
"""

import json
import urllib.request
import urllib.error


SYSTEM_PROMPT = """你是 Nexus Agent，一个强大的 AI 智能体助手。

## 核心能力
1. 智能对话 — 理解上下文，给出有价值的回答
2. 自进化学习 — 从每次交互中积累经验
3. 工具调用 — 可以执行代码、搜索网页、管理文件
4. 持久记忆 — 跨会话记住重要信息

## 工具调用规则
当你需要使用工具时，在回复中包含工具调用的 JSON 代码块。格式：

```json
{"tool": "工具名", "params": {"参数名": "值"}}
```

### 示例

用户：帮我搜索一下 Python 异步编程
你：好的，我来搜索。
```json
{"tool": "web_search", "params": {"query": "Python 异步编程 async await"}}
```

用户：帮我写一个 hello.py 文件
你：好的，我来创建。
```json
{"tool": "write_file", "params": {"path": "hello.py", "content": "print('Hello, World!')"}}
```

用户：帮我运行这段代码
你：我来执行。
```json
{"tool": "execute_code", "params": {"code": "print(1+2+3)", "lang": "python"}}
```

用户：看看当前目录有什么
你：
```json
{"tool": "list_dir", "params": {"path": "."}}
```

用户：读取 config.json
你：
```json
{"tool": "read_file", "params": {"path": "config.json"}}
```

## 重要规则
- 工具调用后，我会把结果给你，请基于结果回答用户
- 可以连续调用多个工具
- 如果工具返回错误，告诉用户并建议解决方案
- 用中文回答，保持专业但不死板
- 如果不确定，诚实说明"""


def chat(messages: list, provider_config: dict, model: str = None) -> dict:
    """
    统一聊天接口
    返回: {"text": str, "tokens": int, "error": str|None}
    """
    ptype = provider_config.get("type", "openai")
    base = provider_config.get("base_url", "")
    key = provider_config.get("api_key", "")
    mdl = model or provider_config.get("default", "gpt-4o")
    temp = float(provider_config.get("temperature", 0.7))
    max_tok = int(provider_config.get("max_tokens", 4096))

    if not base:
        return {"text": "", "tokens": 0, "error": "未配置 API 地址"}

    try:
        if ptype == "anthropic":
            return _call_anthropic(base, key, messages, mdl, max_tok, temp)
        elif ptype == "ollama":
            return _call_ollama(base, mdl, messages, max_tok, temp)
        else:
            return _call_openai_compat(base, key, mdl, messages, max_tok, temp)
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")[:300]
        return {"text": "", "tokens": 0, "error": f"HTTP {e.code}: {body}"}
    except urllib.error.URLError as e:
        return {"text": "", "tokens": 0, "error": f"网络错误: {e.reason}"}
    except Exception as e:
        return {"text": "", "tokens": 0, "error": str(e)}


def _call_openai_compat(base, key, model, messages, max_tokens, temp) -> dict:
    """OpenAI 兼容格式（覆盖 90% 提供商）"""
    url = f"{base.rstrip('/')}/chat/completions"
    payload = json.dumps({
        "model": model,
        "messages": messages,
        "max_tokens": max_tokens,
        "temperature": temp,
    }).encode()
    headers = {"Content-Type": "application/json"}
    if key:
        headers["Authorization"] = f"Bearer {key}"
    req = urllib.request.Request(url, data=payload, headers=headers)
    with urllib.request.urlopen(req, timeout=120) as r:
        d = json.loads(r.read())
        text = d["choices"][0]["message"]["content"]
        tok = d.get("usage", {}).get("total_tokens", 0)
        return {"text": text, "tokens": tok, "error": None}


def _call_anthropic(base, key, messages, model, max_tokens, temp) -> dict:
    """Anthropic Claude 格式"""
    url = f"{base.rstrip('/')}/v1/messages"
    sys_text = ""
    claude_msgs = []
    for m in messages:
        if m["role"] == "system":
            sys_text += m["content"] + "\n"
        else:
            claude_msgs.append(m)
    payload = json.dumps({
        "model": model, "max_tokens": max_tokens, "temperature": temp,
        "system": sys_text.strip(), "messages": claude_msgs,
    }).encode()
    headers = {
        "Content-Type": "application/json",
        "x-api-key": key, "anthropic-version": "2023-06-01",
    }
    req = urllib.request.Request(url, data=payload, headers=headers)
    with urllib.request.urlopen(req, timeout=120) as r:
        d = json.loads(r.read())
        text = d["content"][0]["text"]
        tok = d.get("usage", {}).get("input_tokens", 0) + d.get("usage", {}).get("output_tokens", 0)
        return {"text": text, "tokens": tok, "error": None}


def _call_ollama(base, model, messages, max_tokens, temp) -> dict:
    """Ollama 本地格式"""
    url = f"{base.rstrip('/')}/api/chat"
    payload = json.dumps({
        "model": model, "messages": messages, "stream": False,
        "options": {"num_predict": max_tokens, "temperature": temp},
    }).encode()
    req = urllib.request.Request(url, data=payload,
                                headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=300) as r:
        d = json.loads(r.read())
        text = d["message"]["content"]
        tok = d.get("eval_count", 0) + d.get("prompt_eval_count", 0)
        return {"text": text, "tokens": tok, "error": None}


def test_connection(provider_config: dict, model: str = None) -> dict:
    """测试 API 连接"""
    msgs = [{"role": "user", "content": "Hi, reply with only: OK"}]
    result = chat(msgs, provider_config, model)
    if result["error"]:
        return {"ok": False, "error": result["error"]}
    return {"ok": True, "reply": result["text"][:100]}
