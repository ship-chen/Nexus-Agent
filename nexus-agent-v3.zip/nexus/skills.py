"""
Nexus v2.0 — 技能系统
加载 SKILL.md 技能文件，注入 AI 上下文
兼容 OpenClaw 技能格式
"""

import os
import re
from pathlib import Path


class Skill:
    """单个技能"""

    def __init__(self, path: str):
        self.path = Path(path)
        self.name = self.path.stem
        self.dir = self.path.parent
        self.content = ""
        self.description = ""
        self.triggers = []
        self.tools = []
        self._parse()

    def _parse(self):
        if not self.path.exists():
            return
        self.content = self.path.read_text(encoding="utf-8", errors="replace")

        # 提取描述
        desc_match = re.search(r'##?\s*(?:Description|描述)\s*\n(.+?)(?:\n#|\Z)',
                              self.content, re.DOTALL | re.IGNORECASE)
        if desc_match:
            self.description = desc_match.group(1).strip()[:200]

        # 提取触发条件
        trigger_match = re.search(r'(?:Use when|触发|When to use)[:\s]*\n(.+?)(?:\n#|\Z)',
                                 self.content, re.DOTALL | re.IGNORECASE)
        if trigger_match:
            self.triggers = [t.strip().strip('- ').strip('* ')
                           for t in trigger_match.group(1).split('\n') if t.strip()]

        # 提取引用的工具/脚本
        for m in re.finditer(r'`(bash|python|node)\s+([^\s`]+)`', self.content):
            self.tools.append({"type": m.group(1), "script": m.group(2)})

        # 提取文件引用
        for m in re.finditer(r'(?:(?:read|cat|source)\s+)?([^\s/`]+\.(?:sh|py|js|md))', self.content):
            existing = [t.get("script", t.get("path", "")) for t in self.tools]
            if m.group(1) not in existing:
                self.tools.append({"type": "file", "path": m.group(1)})

    @property
    def summary(self) -> str:
        """技能摘要（注入系统提示用）"""
        lines = [f"### 技能: {self.name}"]
        if self.description:
            lines.append(f"描述: {self.description}")
        if self.triggers:
            lines.append("触发条件: " + "; ".join(self.triggers[:3]))
        # 截取关键指令部分（不要全部注入，太长）
        content_lines = self.content.split('\n')
        key_lines = []
        in_code = False
        for line in content_lines:
            if line.strip().startswith('```'):
                in_code = not in_code
                continue
            if in_code and len(key_lines) < 10:
                key_lines.append(line)
            elif any(kw in line.lower() for kw in ['步骤', 'step', '执行', 'run', '使用', 'use']):
                key_lines.append(line)
        if key_lines:
            lines.append("关键步骤:\n" + "\n".join(key_lines[:8]))
        return "\n".join(lines)


class SkillManager:
    """技能管理器"""

    def __init__(self, skills_dir: str = None):
        self.skills: dict[str, Skill] = {}
        self.dirs: list[Path] = []

        # 默认技能目录
        if skills_dir:
            self.dirs.append(Path(skills_dir))

        # 也搜索常见位置
        base = Path(os.environ.get("NEXUS_BASE", os.path.expanduser("~/.nexus")))
        self.dirs.append(base / "skills")

        # OpenClaw 兼容路径
        oc_skills = Path.home() / ".openclaw" / "skills"
        if oc_skills.exists():
            self.dirs.append(oc_skills)

        self.scan()

    def scan(self):
        """扫描所有技能目录"""
        self.skills.clear()
        for d in self.dirs:
            if not d.exists():
                d.mkdir(parents=True, exist_ok=True)
                continue
            for md in d.rglob("SKILL.md"):
                skill = Skill(str(md))
                if skill.content:
                    self.skills[skill.name] = skill
            # 也扫描 .md 文件（有些技能直接是 md）
            for md in d.glob("*.md"):
                if md.name not in ("README.md", "SKILL.md") and md.stem not in self.skills:
                    skill = Skill(str(md))
                    if skill.content and len(skill.content) > 50:
                        self.skills[skill.name] = skill

    def add_skill(self, name: str, content: str):
        """手动添加技能"""
        if not self.dirs:
            return
        d = self.dirs[0]
        d.mkdir(parents=True, exist_ok=True)
        path = d / f"{name}.md"
        path.write_text(content, encoding="utf-8")
        self.skills[name] = Skill(str(path))

    def get_context(self, max_chars: int = 2000) -> str:
        """获取技能上下文（注入系统提示）"""
        if not self.skills:
            return ""
        parts = ["\n## 可用技能"]
        total = 0
        for name, skill in self.skills.items():
            summary = skill.summary
            if total + len(summary) > max_chars:
                break
            parts.append(summary)
            total += len(summary)
        return "\n\n".join(parts)

    def find_relevant(self, query: str, limit: int = 3) -> list:
        """根据查询找相关技能"""
        scored = []
        query_lower = query.lower()
        for name, skill in self.skills.items():
            score = 0
            # 名称匹配
            if name.lower() in query_lower or query_lower in name.lower():
                score += 3
            # 描述匹配
            if skill.description and any(w in skill.description.lower()
                                         for w in query_lower.split()):
                score += 2
            # 触发条件匹配
            for trigger in skill.triggers:
                if any(w in trigger.lower() for w in query_lower.split()):
                    score += 1
            if score > 0:
                scored.append((score, skill))
        scored.sort(key=lambda x: -x[0])
        return [s for _, s in scored[:limit]]

    def list_skills(self) -> list:
        """列出所有技能"""
        return [
            {"name": s.name, "desc": s.description, "triggers": s.triggers,
             "tools": len(s.tools), "path": str(s.path)}
            for s in self.skills.values()
        ]
