"""
Nexus v2.0 — 记忆系统
融合 OpenClaw 文件记忆 + Hermes SQLite 分层持久化
"""

import sqlite3
import json
from datetime import datetime
from pathlib import Path


class Memory:
    """分层持久化记忆系统"""

    def __init__(self, base_dir: str):
        self.db = Path(base_dir) / "memory.db"
        self._init()

    def _conn(self):
        return sqlite3.connect(str(self.db))

    def _init(self):
        with self._conn() as conn:
            conn.executescript("""
                CREATE TABLE IF NOT EXISTS memories (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    category TEXT NOT NULL DEFAULT 'general',
                    content TEXT NOT NULL,
                    importance REAL DEFAULT 0.5,
                    access_count INTEGER DEFAULT 0,
                    created TEXT NOT NULL,
                    accessed TEXT,
                    tags TEXT DEFAULT ''
                );
                CREATE TABLE IF NOT EXISTS conversations (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    session TEXT NOT NULL,
                    role TEXT NOT NULL,
                    content TEXT NOT NULL,
                    model TEXT DEFAULT '',
                    tokens INTEGER DEFAULT 0,
                    ts TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS skills (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT UNIQUE NOT NULL,
                    desc TEXT,
                    content TEXT NOT NULL,
                    category TEXT DEFAULT 'learned',
                    auto INTEGER DEFAULT 0,
                    uses INTEGER DEFAULT 0,
                    success REAL DEFAULT 1.0,
                    created TEXT NOT NULL,
                    used TEXT,
                    version INTEGER DEFAULT 1
                );
                CREATE TABLE IF NOT EXISTS tasks (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    cron TEXT,
                    payload TEXT NOT NULL,
                    enabled INTEGER DEFAULT 1,
                    last_run TEXT,
                    next_run TEXT,
                    created TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS evolution (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    event TEXT NOT NULL,
                    detail TEXT,
                    impact TEXT DEFAULT '',
                    ts TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS notes (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    title TEXT NOT NULL,
                    content TEXT NOT NULL,
                    category TEXT DEFAULT 'note',
                    pinned INTEGER DEFAULT 0,
                    created TEXT NOT NULL,
                    updated TEXT
                );
            """)

    def _now(self):
        return datetime.now().isoformat(timespec="seconds")

    # ── 记忆 ──
    def remember(self, content, category="general", importance=0.5, tags=""):
        with self._conn() as conn:
            cur = conn.execute(
                "INSERT INTO memories(category,content,importance,created,tags) VALUES(?,?,?,?,?)",
                (category, content, importance, self._now(), tags))
            return cur.lastrowid

    def recall(self, query, limit=5):
        with self._conn() as conn:
            conn.row_factory = sqlite3.Row
            like = f"%{query}%"
            rows = conn.execute(
                "SELECT * FROM memories WHERE content LIKE ? OR tags LIKE ? "
                "ORDER BY importance DESC, access_count DESC LIMIT ?",
                (like, like, limit)).fetchall()
            for r in rows:
                conn.execute("UPDATE memories SET access_count=access_count+1,accessed=? WHERE id=?",
                             (self._now(), r["id"]))
            return [dict(r) for r in rows]

    def get_all_memories(self, category=None, limit=100):
        with self._conn() as conn:
            conn.row_factory = sqlite3.Row
            if category:
                rows = conn.execute("SELECT * FROM memories WHERE category=? ORDER BY importance DESC LIMIT ?",
                                    (category, limit)).fetchall()
            else:
                rows = conn.execute("SELECT * FROM memories ORDER BY importance DESC LIMIT ?",
                                    (limit,)).fetchall()
            return [dict(r) for r in rows]

    # ── 对话 ──
    def save_msg(self, session, role, content, model="", tokens=0):
        with self._conn() as conn:
            conn.execute("INSERT INTO conversations(session,role,content,model,tokens,ts) VALUES(?,?,?,?,?,?)",
                         (session, role, content, model, tokens, self._now()))

    def get_msgs(self, session, limit=50):
        with self._conn() as conn:
            conn.row_factory = sqlite3.Row
            rows = conn.execute(
                "SELECT * FROM conversations WHERE session=? ORDER BY id DESC LIMIT ?",
                (session, limit)).fetchall()
            return [dict(r) for r in reversed(rows)]

    def get_sessions(self, limit=20):
        with self._conn() as conn:
            conn.row_factory = sqlite3.Row
            return [dict(r) for r in conn.execute(
                "SELECT session, MIN(ts) as started, COUNT(*) as msgs, "
                "SUM(tokens) as total_tokens FROM conversations "
                "GROUP BY session ORDER BY MAX(id) DESC LIMIT ?",
                (limit,)).fetchall()]

    # ── 技能 ──
    def add_skill(self, name, desc, content, category="learned", auto=False):
        with self._conn() as conn:
            try:
                cur = conn.execute(
                    "INSERT INTO skills(name,desc,content,category,auto,created,used) VALUES(?,?,?,?,?,?,?)",
                    (name, desc, content, category, int(auto), self._now(), self._now()))
                return cur.lastrowid
            except sqlite3.IntegrityError:
                conn.execute("UPDATE skills SET uses=uses+1,used=?,version=version+1 WHERE name=?",
                             (self._now(), name))

    def get_skills(self, category=None):
        with self._conn() as conn:
            conn.row_factory = sqlite3.Row
            if category:
                return [dict(r) for r in conn.execute(
                    "SELECT * FROM skills WHERE category=? ORDER BY uses DESC", (category,)).fetchall()]
            return [dict(r) for r in conn.execute("SELECT * FROM skills ORDER BY uses DESC").fetchall()]

    def auto_learn(self, task, result, success=True):
        if success and len(result) > 30:
            import hashlib
            name = f"auto_{hashlib.md5(task.encode()).hexdigest()[:8]}"
            self.add_skill(name, f"自动学习: {task[:80]}", result[:2000], "learned", True)
            self.log_evolution("auto_learn", task[:200], "skill_created")

    # ── 定时任务 ──
    def add_task(self, name, cron, payload, enabled=True):
        with self._conn() as conn:
            cur = conn.execute("INSERT INTO tasks(name,cron,payload,enabled,created) VALUES(?,?,?,?,?)",
                               (name, cron, payload, int(enabled), self._now()))
            return cur.lastrowid

    def get_tasks(self, enabled_only=False):
        with self._conn() as conn:
            conn.row_factory = sqlite3.Row
            if enabled_only:
                return [dict(r) for r in conn.execute(
                    "SELECT * FROM tasks WHERE enabled=1 ORDER BY id").fetchall()]
            return [dict(r) for r in conn.execute("SELECT * FROM tasks ORDER BY id").fetchall()]

    def update_task_run(self, task_id):
        with self._conn() as conn:
            conn.execute("UPDATE tasks SET last_run=? WHERE id=?", (self._now(), task_id))

    # ── 笔记 ──
    def add_note(self, title, content, category="note"):
        with self._conn() as conn:
            cur = conn.execute("INSERT INTO notes(title,content,category,created,updated) VALUES(?,?,?,?,?)",
                               (title, content, category, self._now(), self._now()))
            return cur.lastrowid

    def get_notes(self, category=None):
        with self._conn() as conn:
            conn.row_factory = sqlite3.Row
            if category:
                return [dict(r) for r in conn.execute(
                    "SELECT * FROM notes WHERE category=? ORDER BY pinned DESC,updated DESC",
                    (category,)).fetchall()]
            return [dict(r) for r in conn.execute(
                "SELECT * FROM notes ORDER BY pinned DESC,updated DESC").fetchall()]

    # ── 进化日志 ──
    def log_evolution(self, event, detail="", impact=""):
        with self._conn() as conn:
            conn.execute("INSERT INTO evolution(event,detail,impact,ts) VALUES(?,?,?,?)",
                         (event, detail, impact, self._now()))

    def get_evolution(self, limit=50):
        with self._conn() as conn:
            conn.row_factory = sqlite3.Row
            return [dict(r) for r in conn.execute(
                "SELECT * FROM evolution ORDER BY id DESC LIMIT ?", (limit,)).fetchall()]

    # ── 统计 ──
    def stats(self):
        with self._conn() as conn:
            def cnt(t): return conn.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0]
            tokens = conn.execute("SELECT COALESCE(SUM(tokens),0) FROM conversations").fetchone()[0]
            auto = conn.execute("SELECT COUNT(*) FROM skills WHERE auto=1").fetchone()[0]
            return {
                "memories": cnt("memories"), "conversations": cnt("conversations"),
                "skills": cnt("skills"), "auto_skills": auto,
                "tasks": cnt("tasks"), "evolutions": cnt("evolution"),
                "notes": cnt("notes"), "total_tokens": tokens,
            }
