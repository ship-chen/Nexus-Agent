"""
Nexus v2.0 — 消息网关
多平台消息集成（Telegram / Discord / 飞书 / 钉钉 / 企业微信）
"""

import json
import urllib.request
import urllib.parse
from pathlib import Path


class MessageGateway:
    """统一消息网关"""

    CHANNELS = {
        "telegram": {
            "name": "Telegram", "icon": "📱",
            "desc": "通过 Bot API 接入",
            "fields": [("bot_token", "Bot Token", True)],
            "api_base": "https://api.telegram.org/bot{token}",
        },
        "discord": {
            "name": "Discord", "icon": "🎮",
            "desc": "通过 Bot Token 接入",
            "fields": [("bot_token", "Bot Token", True), ("channel_id", "频道 ID", False)],
            "api_base": "https://discord.com/api/v10",
        },
        "feishu": {
            "name": "飞书", "icon": "🐦",
            "desc": "通过飞书机器人接入",
            "fields": [("app_id", "App ID", False), ("app_secret", "App Secret", True)],
            "api_base": "https://open.feishu.cn/open-apis",
        },
        "dingtalk": {
            "name": "钉钉", "icon": "📌",
            "desc": "通过钉钉机器人接入",
            "fields": [("webhook", "Webhook URL", True)],
        },
        "wechat_work": {
            "name": "企业微信", "icon": "💬",
            "desc": "通过企业微信机器人接入",
            "fields": [("webhook", "Webhook URL", True)],
        },
        "slack": {
            "name": "Slack", "icon": "💼",
            "desc": "通过 Slack Bot 接入",
            "fields": [("bot_token", "Bot Token", True)],
            "api_base": "https://slack.com/api",
        },
        "whatsapp": {
            "name": "WhatsApp", "icon": "📞",
            "desc": "通过 WhatsApp Business API",
            "fields": [("token", "Access Token", True), ("phone_id", "Phone Number ID", False)],
        },
        "webhook": {
            "name": "自定义 Webhook", "icon": "🔗",
            "desc": "通用 HTTP Webhook",
            "fields": [("url", "Webhook URL", True), ("secret", "Secret", True)],
        },
    }

    def __init__(self, config_dir: str):
        self.config_path = Path(config_dir) / "channels.json"
        self.channels: dict = {}
        self._load()

    def _load(self):
        if self.config_path.exists():
            try:
                with open(self.config_path) as f:
                    self.channels = json.load(f)
            except Exception:
                pass

    def save(self):
        self.config_path.parent.mkdir(parents=True, exist_ok=True)
        with open(self.config_path, "w") as f:
            json.dump(self.channels, f, indent=2, ensure_ascii=False)

    def configure(self, channel: str, config: dict):
        """配置一个消息渠道"""
        self.channels[channel] = config
        self.save()

    def get_config(self, channel: str) -> dict:
        return self.channels.get(channel, {})

    def list_configured(self) -> list:
        result = []
        for ch_id, ch_cfg in self.channels.items():
            info = self.CHANNELS.get(ch_id, {})
            result.append({
                "id": ch_id,
                "name": info.get("name", ch_id),
                "icon": info.get("icon", "📱"),
                "configured": bool(ch_cfg),
            })
        return result

    def send(self, channel: str, message: str, target: str = None) -> dict:
        """发送消息到指定渠道"""
        cfg = self.channels.get(channel)
        if not cfg:
            return {"ok": False, "error": f"渠道 {channel} 未配置"}

        try:
            if channel == "telegram":
                return self._send_telegram(cfg, message, target)
            elif channel == "discord":
                return self._send_discord(cfg, message, target)
            elif channel == "dingtalk":
                return self._send_dingtalk(cfg, message)
            elif channel == "wechat_work":
                return self._send_wechat_work(cfg, message)
            elif channel == "slack":
                return self._send_slack(cfg, message, target)
            elif channel == "webhook":
                return self._send_webhook(cfg, message)
            else:
                return {"ok": False, "error": f"渠道 {channel} 暂不支持发送"}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def _send_telegram(self, cfg, msg, target):
        token = cfg.get("bot_token", "")
        chat_id = target or cfg.get("chat_id", "")
        url = f"https://api.telegram.org/bot{token}/sendMessage"
        data = json.dumps({"chat_id": chat_id, "text": msg,
                          "parse_mode": "Markdown"}).encode()
        req = urllib.request.Request(url, data=data,
                                    headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=15) as r:
            return {"ok": True, "response": json.loads(r.read())}

    def _send_discord(self, cfg, msg, target):
        token = cfg.get("bot_token", "")
        ch = target or cfg.get("channel_id", "")
        url = f"https://discord.com/api/v10/channels/{ch}/messages"
        data = json.dumps({"content": msg}).encode()
        req = urllib.request.Request(url, data=data, headers={
            "Content-Type": "application/json",
            "Authorization": f"Bot {token}"
        })
        with urllib.request.urlopen(req, timeout=15) as r:
            return {"ok": True, "response": json.loads(r.read())}

    def _send_dingtalk(self, cfg, msg):
        url = cfg.get("webhook", "")
        data = json.dumps({"msgtype": "text", "text": {"content": msg}}).encode()
        req = urllib.request.Request(url, data=data,
                                    headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=15) as r:
            return {"ok": True, "response": json.loads(r.read())}

    def _send_wechat_work(self, cfg, msg):
        url = cfg.get("webhook", "")
        data = json.dumps({"msgtype": "text", "text": {"content": msg}}).encode()
        req = urllib.request.Request(url, data=data,
                                    headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=15) as r:
            return {"ok": True, "response": json.loads(r.read())}

    def _send_slack(self, cfg, msg, target):
        token = cfg.get("bot_token", "")
        ch = target or cfg.get("channel", "")
        url = "https://slack.com/api/chat.postMessage"
        data = json.dumps({"channel": ch, "text": msg}).encode()
        req = urllib.request.Request(url, data=data, headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {token}"
        })
        with urllib.request.urlopen(req, timeout=15) as r:
            return {"ok": True, "response": json.loads(r.read())}

    def _send_webhook(self, cfg, msg):
        url = cfg.get("url", "")
        data = json.dumps({"message": msg, "source": "nexus-agent"}).encode()
        req = urllib.request.Request(url, data=data,
                                    headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=15) as r:
            return {"ok": True, "status": r.status}
