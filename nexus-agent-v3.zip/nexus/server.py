"""
Nexus Agent v3.0 — Web 后端
Flask API + 静态资源服务
"""

import json
import os
import sys
import webbrowser
import threading
from http.server import HTTPServer, SimpleHTTPRequestHandler
from pathlib import Path

# ── 项目根目录 ──
if getattr(sys, 'frozen', False):
    BASE = Path(sys.executable).parent
else:
    BASE = Path(__file__).parent

STATIC = BASE / "web"


class NexusAPI:
    """API 处理器"""

    def __init__(self):
        from nexus.engine import Engine
        self.engine = Engine(str(BASE / "data"))
        self._ensure_first_run()

    def _ensure_first_run(self):
        if self.engine.config.is_first_run:
            # 标记需要向导
            pass

    def handle(self, path: str, method: str, body: dict = None) -> dict:
        """路由 API 请求"""
        body = body or {}

        # ── 对话 ──
        if path == "/api/chat" and method == "POST":
            msg = body.get("message", "")
            if not msg:
                return {"error": "消息不能为空"}
            result = self.engine.chat(msg)
            return result

        # ── 配置 ──
        if path == "/api/config" and method == "GET":
            return {"config": self.engine.config.data, "configured": self.engine.is_configured}

        if path == "/api/config" and method == "POST":
            for k, v in body.items():
                self.engine.config.set(k, v)
            return {"ok": True}

        # ── 提供商 ──
        if path == "/api/providers" and method == "GET":
            from nexus.providers import PROVIDERS, REGIONS
            active = self.engine.config.data.get("active_provider", "")
            return {"providers": PROVIDERS, "regions": REGIONS, "active": active}

        if path == "/api/providers/set" and method == "POST":
            pid = body.get("provider", "")
            cfg = body.get("config", {})
            self.engine.config.set(f"providers.{pid}", cfg)
            self.engine.config.data["active_provider"] = pid
            self.engine.config.data["active_model"] = cfg.get("default_model", cfg.get("default", ""))
            self.engine.config.mark_configured()
            return {"ok": True}

        if path == "/api/providers/test" and method == "POST":
            from nexus.ai_client import test_connection
            return test_connection(body)

        # ── 技能 ──
        if path == "/api/skills" and method == "GET":
            file_skills = self.engine.skills.list_skills()
            db_skills = self.engine.memory.get_skills()
            return {"file_skills": file_skills, "db_skills": db_skills}

        # ── 记忆 ──
        if path == "/api/memory" and method == "GET":
            q = body.get("query", "")
            if q:
                mems = self.engine.memory.recall(q, limit=30)
            else:
                mems = self.engine.memory.get_all_memories(limit=50)
            return {"memories": mems, "stats": self.engine.memory.stats()}

        # ── 工具 ──
        if path == "/api/tools" and method == "GET":
            from nexus.tools import TOOLS
            return {"tools": {k: {"name": v["name"], "desc": v["desc"],
                                  "icon": v["icon"], "params": v["params"]}
                             for k, v in TOOLS.items()}}

        if path == "/api/tools/call" and method == "POST":
            from nexus.tools import call_tool
            name = body.get("tool", "")
            params = body.get("params", {})
            result = call_tool(name, **params)
            return {"result": result}

        # ── MCP ──
        if path == "/api/mcp" and method == "GET":
            from nexus.mcp import PRESET_MCP_SERVERS
            return {"presets": PRESET_MCP_SERVERS, "connected": self.engine.mcp.list_tools()}

        # ── 消息网关 ──
        if path == "/api/gateway" and method == "GET":
            from nexus.gateway import MessageGateway
            return {"channels": self.engine.gateway.CHANNELS,
                    "configured": self.engine.gateway.list_configured()}

        if path == "/api/gateway/send" and method == "POST":
            ch = body.get("channel", "")
            msg = body.get("message", "")
            target = body.get("target")
            return self.engine.gateway.send(ch, msg, target)

        # ── 会话 ──
        if path == "/api/sessions" and method == "GET":
            return {"sessions": self.engine.sessions.list_all(),
                    "active": self.engine.sessions._active_id}

        if path == "/api/sessions/new" and method == "POST":
            name = body.get("name")
            s = self.engine.sessions.create(name)
            return {"id": s.id, "name": s.name}

        # ── 子代理 ──
        if path == "/api/subagents" and method == "GET":
            return {"agents": self.engine.subagents.list_all()}

        if path == "/api/subagents/spawn" and method == "POST":
            name = body.get("name", "子代理")
            task = body.get("task", "")
            aid = self.engine.subagents.spawn(name, task)
            return {"id": aid}

        # ── 统计 ──
        if path == "/api/stats" and method == "GET":
            return self.engine.get_stats()

        # ── 进化 ──
        if path == "/api/evolution" and method == "GET":
            return {"events": self.engine.memory.get_evolution()}

        # ── 定时任务 ──
        if path == "/api/tasks" and method == "GET":
            return {"tasks": self.engine.memory.get_tasks()}

        # ── 笔记 ──
        if path == "/api/notes" and method == "GET":
            return {"notes": self.engine.memory.get_notes()}

        if path == "/api/notes" and method == "POST":
            title = body.get("title", "")
            content = body.get("content", "")
            nid = self.engine.memory.add_note(title, content)
            return {"id": nid}

        # ── 语音 ──
        if path == "/api/voice" and method == "GET":
            return {"available": self.engine.voice.available,
                    "engine": self.engine.voice.tts_engine,
                    "voices": self.engine.voice.list_voices()}

        if path == "/api/voice/speak" and method == "POST":
            text = body.get("text", "")
            voice = body.get("voice")
            result = self.engine.voice.speak(text, voice)
            return {"result": result}

        # ── 心跳 ──
        if path == "/api/heartbeat" and method == "POST":
            self.engine.heartbeat.beat_now()
            return {"ok": True}

        return {"error": f"未知接口: {path}"}


# ── HTTP 服务器 ──

api = NexusAPI()

class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(STATIC), **kwargs)

    def do_GET(self):
        if self.path.startswith("/api/"):
            self._json_response(api.handle(self.path, "GET"))
        elif self.path == "/" or self.path == "":
            self.path = "/index.html"
            super().do_GET()
        else:
            super().do_GET()

    def do_POST(self):
        length = int(self.headers.get("Content-Length", 0))
        body = {}
        if length:
            raw = self.rfile.read(length)
            try:
                body = json.loads(raw)
            except Exception:
                pass
        self._json_response(api.handle(self.path, "POST", body))

    def _json_response(self, data):
        resp = json.dumps(data, ensure_ascii=False).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", len(resp))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(resp)

    def log_message(self, format, *args):
        pass  # 静默日志


def start_server(port=9800, open_browser=True):
    """启动服务器"""
    server = HTTPServer(("127.0.0.1", port), Handler)
    print(f"⚡ Nexus Agent v3.0")
    print(f"   http://127.0.0.1:{port}")
    if open_browser:
        threading.Timer(0.5, lambda: webbrowser.open(f"http://127.0.0.1:{port}")).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n👋 已停止")
        server.server_close()
