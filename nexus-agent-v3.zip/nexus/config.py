"""
Nexus v2.0 — 核心配置
全局配置管理 + 首次运行检测
"""

import json
import os
from pathlib import Path


DEFAULT_CONFIG = {
    "version": "2.0.0",
    "first_run": True,
    "theme": "light",
    "language": "zh-CN",

    # 当前活跃提供商和模型
    "active_provider": "",
    "active_model": "",

    # 已配置的提供商 {provider_id: {api_key, base_url, default_model, ...}}
    "providers": {},

    # 记忆设置
    "memory": {
        "auto_learn": True,
        "max_context": 20,
        "importance_threshold": 0.3,
    },

    # 安全设置
    "security": {
        "sandbox": True,
        "injection_detect": True,
        "credential_filter": True,
    },

    # 插件设置
    "plugins": {
        "web_search": {"enabled": True, "engine": "duckduckgo"},
        "file_ops": {"enabled": True},
        "code_exec": {"enabled": True, "timeout": 30},
        "scheduler": {"enabled": True},
    },

    # UI 设置
    "ui": {
        "show_timestamps": True,
        "animations": True,
        "compact": False,
        "sidebar_collapsed": False,
    },
}


class Config:
    """全局配置管理器"""

    def __init__(self, base_dir: str = None):
        if base_dir is None:
            base_dir = os.environ.get("NEXUS_BASE",
                os.path.join(os.path.expanduser("~"), ".nexus"))
        self.base = Path(base_dir)
        self.base.mkdir(parents=True, exist_ok=True)
        self.path = self.base / "config.json"
        self.data = dict(DEFAULT_CONFIG)
        self._load()

    def _load(self):
        if self.path.exists():
            try:
                with open(self.path, "r", encoding="utf-8") as f:
                    saved = json.load(f)
                self._merge(self.data, saved)
            except Exception:
                pass

    def save(self):
        with open(self.path, "w", encoding="utf-8") as f:
            json.dump(self.data, f, indent=2, ensure_ascii=False)

    def get(self, dotkey: str, default=None):
        keys = dotkey.split(".")
        v = self.data
        for k in keys:
            if isinstance(v, dict):
                v = v.get(k)
            else:
                return default
            if v is None:
                return default
        return v

    def set(self, dotkey: str, value):
        keys = dotkey.split(".")
        d = self.data
        for k in keys[:-1]:
            d = d.setdefault(k, {})
        d[keys[-1]] = value
        self.save()

    @property
    def is_first_run(self) -> bool:
        return self.data.get("first_run", True)

    def mark_configured(self):
        self.data["first_run"] = False
        self.save()

    def get_active_provider_config(self) -> dict:
        """获取当前活跃提供商的完整配置"""
        pid = self.data.get("active_provider", "")
        if not pid:
            return {}
        return self.data.get("providers", {}).get(pid, {})

    def _merge(self, base, override):
        for k, v in override.items():
            if k in base and isinstance(base[k], dict) and isinstance(v, dict):
                self._merge(base[k], v)
            else:
                base[k] = v
