"""
Nexus v2.0 — 语音系统
TTS 文本转语音 + STT 语音识别
"""

import os
import subprocess
import tempfile
from pathlib import Path


class VoiceEngine:
    """语音引擎"""

    def __init__(self):
        self.tts_engine = self._detect_tts()
        self.stt_engine = self._detect_stt()

    def _detect_tts(self) -> str:
        """检测可用的 TTS 引擎"""
        # macOS
        if os.path.exists("/usr/bin/say"):
            return "say"
        # Linux espeak
        if subprocess.run(["which", "espeak"], capture_output=True).returncode == 0:
            return "espeak"
        # Windows SAPI
        try:
            import pyttsx3
            return "pyttsx3"
        except ImportError:
            pass
        # 在线 TTS (edge-tts)
        try:
            import edge_tts
            return "edge_tts"
        except ImportError:
            pass
        return "none"

    def _detect_stt(self) -> str:
        """检测可用的 STT 引擎"""
        try:
            import speech_recognition
            return "speech_recognition"
        except ImportError:
            pass
        # whisper
        if subprocess.run(["which", "whisper"], capture_output=True).returncode == 0:
            return "whisper"
        return "none"

    def speak(self, text: str, voice: str = None, rate: int = 150) -> str:
        """文本转语音，返回音频文件路径"""
        if self.tts_engine == "none":
            return "⚠️ 无可用的 TTS 引擎"

        try:
            if self.tts_engine == "say":
                # macOS
                voice_arg = ["-v", voice] if voice else []
                subprocess.run(["say"] + voice_arg + ["-r", str(rate), text], check=True)
                return "✅ 已播放"

            elif self.tts_engine == "espeak":
                # Linux
                voice_arg = ["-v", voice or "zh"] if voice else []
                subprocess.run(["espeak"] + voice_arg + ["-s", str(rate), text], check=True)
                return "✅ 已播放"

            elif self.tts_engine == "pyttsx3":
                import pyttsx3
                engine = pyttsx3.init()
                if voice:
                    engine.setProperty('voice', voice)
                engine.setProperty('rate', rate)
                engine.say(text)
                engine.runAndWait()
                return "✅ 已播放"

            elif self.tts_engine == "edge_tts":
                # Edge TTS (高质量)
                import asyncio
                import edge_tts
                output = os.path.join(tempfile.gettempdir(), "nexus_tts.mp3")
                voice = voice or "zh-CN-XiaoxiaoNeural"

                async def _tts():
                    communicate = edge_tts.Communicate(text, voice)
                    await communicate.save(output)

                asyncio.run(_tts())
                # 尝试播放
                if os.path.exists("/usr/bin/mpv"):
                    subprocess.Popen(["mpv", "--no-video", output])
                elif os.path.exists("/usr/bin/ffplay"):
                    subprocess.Popen(["ffplay", "-nodisp", "-autoexit", output])
                return output

        except Exception as e:
            return f"⚠️ TTS 错误: {e}"

    def save_audio(self, text: str, path: str, voice: str = None) -> str:
        """保存语音到文件"""
        try:
            if self.tts_engine == "edge_tts":
                import asyncio
                import edge_tts
                voice = voice or "zh-CN-XiaoxiaoNeural"

                async def _tts():
                    communicate = edge_tts.Communicate(text, voice)
                    await communicate.save(path)

                asyncio.run(_tts())
                return f"✅ 已保存到 {path}"
            elif self.tts_engine == "espeak":
                subprocess.run(["espeak", "-w", path, text], check=True)
                return f"✅ 已保存到 {path}"
            return "⚠️ 当前引擎不支持保存文件"
        except Exception as e:
            return f"⚠️ 保存失败: {e}"

    def list_voices(self) -> list:
        """列出可用声音"""
        voices = []
        if self.tts_engine == "edge_tts":
            voices = [
                {"id": "zh-CN-XiaoxiaoNeural", "name": "晓晓（女）", "lang": "中文"},
                {"id": "zh-CN-YunxiNeural", "name": "云希（男）", "lang": "中文"},
                {"id": "zh-CN-YunjianNeural", "name": "云健（男）", "lang": "中文"},
                {"id": "zh-CN-XiaoyiNeural", "name": "晓艺（女）", "lang": "中文"},
                {"id": "en-US-JennyNeural", "name": "Jenny (F)", "lang": "English"},
                {"id": "en-US-GuyNeural", "name": "Guy (M)", "lang": "English"},
                {"id": "ja-JP-NanamiNeural", "name": "Nanami (F)", "lang": "日本語"},
            ]
        elif self.tts_engine == "espeak":
            voices = [
                {"id": "zh", "name": "中文", "lang": "中文"},
                {"id": "en", "name": "English", "lang": "English"},
            ]
        return voices

    @property
    def available(self):
        return self.tts_engine != "none"
