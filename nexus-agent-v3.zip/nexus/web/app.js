/* Nexus Agent v3.0 — 前端逻辑 */
const API = '';

// ── 页面切换 ──
function showPage(name) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  const page = document.getElementById('page-' + name);
  const nav = document.querySelector(`[data-page="${name}"]`);
  if (page) page.classList.add('active');
  if (nav) nav.classList.add('active');
  // 加载数据
  const loaders = {
    providers: loadProviders, tools: loadTools, skills: loadSkills,
    mcp: loadMCP, gateway: loadGateway, memory: loadMemory,
    evolution: loadEvolution, voice: loadVoice, settings: loadSettings,
  };
  if (loaders[name]) loaders[name]();
}

// ── API 调用 ──
async function api(path, method = 'GET', body = null) {
  const opts = { method, headers: { 'Content-Type': 'application/json' } };
  if (body) opts.body = JSON.stringify(body);
  const r = await fetch(API + path, opts);
  return r.json();
}

// ── 对话 ──
let chatHistory = [];
async function sendMsg() {
  const input = document.getElementById('chat-input');
  const msg = input.value.trim();
  if (!msg) return;
  input.value = '';

  // 清除欢迎
  const container = document.getElementById('chat-messages');
  if (container.querySelector('.chat-welcome')) container.innerHTML = '';

  // 用户消息
  addBubble(msg, 'user');

  // 加载指示
  const thinking = document.createElement('div');
  thinking.className = 'chat-bubble assistant';
  thinking.innerHTML = '<span class="typing">💭 思考中...</span>';
  container.appendChild(thinking);
  container.scrollTop = container.scrollHeight;

  try {
    const r = await api('/api/chat', 'POST', { message: msg });
    thinking.remove();
    addBubble(r.text || r.error || '无回复', 'assistant');
    if (r.tool_used) addToolInfo('🔧 调用了工具');
    if (r.learned) addToolInfo('🧬 已自动学习');
    if (r.memories_used) addToolInfo(`🧠 使用了 ${r.memories_used} 条记忆`);
  } catch (e) {
    thinking.remove();
    addBubble('⚠️ 请求失败: ' + e.message, 'assistant');
  }
}

function addBubble(text, role) {
  const container = document.getElementById('chat-messages');
  const div = document.createElement('div');
  div.className = 'chat-bubble ' + role;
  div.innerHTML = text.replace(/\n/g, '<br>');
  container.appendChild(div);
  container.scrollTop = container.scrollHeight;
}

function addToolInfo(text) {
  const container = document.getElementById('chat-messages');
  const div = document.createElement('div');
  div.className = 'chat-tool-info';
  div.textContent = text;
  container.appendChild(div);
}

function newSession() {
  document.getElementById('chat-messages').innerHTML = `
    <div class="chat-welcome">
      <div class="big-icon">⚡</div>
      <h2>新对话</h2>
      <p>输入任意问题开始对话，我会自动搜索记忆、调用工具、学习经验</p>
    </div>`;
}

// ── 提供商 ──
async function loadProviders() {
  const data = await api('/api/providers');
  const el = document.getElementById('providers-content');
  const regions = { cn: '🇨🇳 国内', intl: '🌍 国际', local: '💻 本地' };
  let html = '';

  for (const [region, label] of Object.entries(regions)) {
    const ps = Object.entries(data.providers).filter(([, p]) => p.region === region);
    if (!ps.length) continue;
    html += `<h3 style="margin:16px 0 8px">${label}</h3><div class="card-grid">`;
    for (const [id, p] of ps) {
      const isActive = id === data.active;
      html += `<div class="card" style="cursor:pointer" onclick="selectProvider('${id}')">
        <div style="display:flex;align-items:center;gap:8px">
          <span style="font-size:24px">${p.icon}</span>
          <div>
            <div style="font-weight:600">${p.name}</div>
            <div style="font-size:12px;color:var(--txt3)">${p.desc}</div>
          </div>
          ${isActive ? '<span style="margin-left:auto;color:var(--success);font-size:12px">✅ 使用中</span>' : ''}
          ${p.free ? '<span style="font-size:10px;background:var(--success-bg);color:var(--success);padding:1px 6px;border-radius:4px">免费</span>' : ''}
        </div>
      </div>`;
    }
    html += '</div>';
  }
  el.innerHTML = html;
}

async function selectProvider(pid) {
  const data = await api('/api/providers');
  const p = data.providers[pid];
  showWizard(pid, p);
}

// ── 向导 ──
function showWizard(pid, p) {
  const overlay = document.getElementById('wizard-overlay');
  overlay.style.display = 'flex';
  const content = document.getElementById('wizard-content');

  let fields = '';
  if (p.needs_key) fields += `<label>API Key</label><input type="password" id="wiz-key" placeholder="sk-xxx 或其他密钥">`;
  fields += `<label>API 地址</label><input type="text" id="wiz-url" value="${p.base_url}">`;
  fields += `<label>默认模型</label><input type="text" id="wiz-model" value="${p.default}">`;
  fields += `<p style="font-size:12px;color:var(--txt3);margin-top:8px">可用: ${p.models.slice(0, 4).join(', ')}</p>`;

  content.innerHTML = `
    <div class="wizard-step">
      <div style="font-size:48px;margin-bottom:12px">${p.icon}</div>
      <h2>${p.name}</h2>
      <p>${p.desc}</p>
      <div class="wizard-form">${fields}</div>
      <div class="wizard-actions">
        <button class="btn btn-ghost" onclick="closeWizard()">取消</button>
        <button class="btn btn-secondary" onclick="testProvider()">🔌 测试</button>
        <button class="btn btn-primary" onclick="saveProvider('${pid}')">✅ 保存并启用</button>
      </div>
      <div id="wiz-status" style="margin-top:12px;font-size:13px"></div>
    </div>`;
}

function closeWizard() {
  document.getElementById('wizard-overlay').style.display = 'none';
}

async function testProvider() {
  const cfg = getConfig();
  document.getElementById('wiz-status').innerHTML = '⏳ 测试中...';
  const r = await api('/api/providers/test', 'POST', cfg);
  document.getElementById('wiz-status').innerHTML = r.ok ?
    `<span style="color:var(--success)">✅ 连接成功: ${r.reply || ''}</span>` :
    `<span style="color:var(--error)">❌ ${r.error}</span>`;
}

async function saveProvider(pid) {
  const cfg = getConfig();
  await api('/api/providers/set', 'POST', { provider: pid, config: cfg });
  closeWizard();
  loadProviders();
  updateHeaderModel();
}

function getConfig() {
  const cfg = {};
  const key = document.getElementById('wiz-key');
  const url = document.getElementById('wiz-url');
  const model = document.getElementById('wiz-model');
  if (key && key.value) cfg.api_key = key.value;
  if (url && url.value) cfg.base_url = url.value;
  if (model && model.value) { cfg.default_model = model.value; cfg.default = model.value; }
  return cfg;
}

// ── 工具 ──
async function loadTools() {
  const data = await api('/api/tools');
  const el = document.getElementById('tools-content');
  let html = '<div class="card-grid">';
  for (const [k, t] of Object.entries(data.tools)) {
    html += `<div class="card">
      <div style="font-size:28px;margin-bottom:8px">${t.icon}</div>
      <div style="font-weight:600">${t.name}</div>
      <div style="font-size:12px;color:var(--txt2);margin:4px 0">${t.desc}</div>
      <div style="font-size:11px;color:var(--txt3)">参数: ${t.params.join(', ') || '无'}</div>
    </div>`;
  }
  html += '</div>';
  el.innerHTML = html;
}

// ── 技能 ──
async function loadSkills() {
  const data = await api('/api/skills');
  const el = document.getElementById('skills-content');
  let html = '';
  if (data.file_skills.length) {
    html += '<h3 style="margin-bottom:8px">📁 文件技能</h3><div class="card-grid">';
    for (const s of data.file_skills) {
      html += `<div class="card"><div style="font-weight:600">📄 ${s.name}</div>
        <div style="font-size:12px;color:var(--txt2)">${s.desc || '无描述'}</div></div>`;
    }
    html += '</div>';
  }
  if (data.db_skills.length) {
    html += '<h3 style="margin:16px 0 8px">🧠 学习技能</h3><div class="card-grid">';
    for (const s of data.db_skills) {
      html += `<div class="card"><div style="font-weight:600">${s.auto ? '🧬' : '🧩'} ${s.name}</div>
        <div style="font-size:12px;color:var(--txt2)">${s.desc || ''}</div>
        <div style="font-size:11px;color:var(--txt3)">使用 ${s.uses} 次</div></div>`;
    }
    html += '</div>';
  }
  if (!data.file_skills.length && !data.db_skills.length) {
    html = '<div style="text-align:center;padding:60px;color:var(--txt3)">🧩 暂无技能<br><small>文件技能: 在 skills/ 放 SKILL.md<br>学习技能: 对话中自动积累</small></div>';
  }
  el.innerHTML = html;
}

// ── MCP ──
async function loadMCP() {
  const data = await api('/api/mcp');
  const el = document.getElementById('mcp-content');
  let html = '<div class="card" style="margin-bottom:16px"><b>💡 MCP</b> 让 AI 连接外部工具服务器</div>';
  html += '<div class="card-grid">';
  for (const [k, p] of Object.entries(data.presets)) {
    html += `<div class="card">
      <div style="font-weight:600">🔌 ${p.name}</div>
      <div style="font-size:12px;color:var(--txt2)">${p.desc}</div>
      <div style="margin-top:8px">
        <label class="toggle"><input type="checkbox" ${p.enabled ? 'checked' : ''}><span class="slider"></span></label>
      </div>
    </div>`;
  }
  html += '</div>';
  el.innerHTML = html;
}

// ── 消息网关 ──
async function loadGateway() {
  const data = await api('/api/gateway');
  const el = document.getElementById('gateway-content');
  let html = '<div class="card-grid">';
  for (const [k, ch] of Object.entries(data.channels)) {
    const cfg = data.configured.find(c => c.id === k);
    html += `<div class="card" style="cursor:pointer">
      <div style="font-size:28px;margin-bottom:8px">${ch.icon}</div>
      <div style="font-weight:600">${ch.name}</div>
      <div style="font-size:12px;color:var(--txt2)">${ch.desc}</div>
      ${cfg ? '<div style="color:var(--success);font-size:12px;margin-top:4px">✅ 已配置</div>' : ''}
    </div>`;
  }
  html += '</div>';
  el.innerHTML = html;
}

// ── 记忆 ──
async function loadMemory() {
  const data = await api('/api/memory');
  const statsEl = document.getElementById('memory-stats');
  const s = data.stats;
  statsEl.innerHTML = [
    { v: s.memories, l: '记忆', c: 'var(--primary)' },
    { v: s.conversations, l: '对话', c: 'var(--teal)' },
    { v: s.skills, l: '技能', c: 'var(--purple)' },
    { v: s.evolutions, l: '进化', c: 'var(--success)' },
  ].map(i => `<div class="stat-card"><div class="stat-value" style="color:${i.c}">${i.v}</div><div class="stat-label">${i.l}</div></div>`).join('');

  const el = document.getElementById('memory-content');
  if (!data.memories.length) {
    el.innerHTML = '<div style="text-align:center;padding:40px;color:var(--txt3)">暂无记忆</div>';
    return;
  }
  el.innerHTML = data.memories.map(m => `
    <div class="card" style="margin-bottom:8px">
      <div style="font-size:14px">${m.content.slice(0, 120)}</div>
      <div style="display:flex;gap:8px;margin-top:8px">
        <span style="font-size:11px;background:var(--info-bg);color:var(--info);padding:2px 8px;border-radius:4px">${m.category}</span>
        <span style="font-size:11px;color:var(--txt3)">${m.created}</span>
      </div>
    </div>`).join('');
}

async function searchMemory(q) {
  if (q.length < 2) return loadMemory();
  const data = await api('/api/memory', 'POST', { query: q });
  const el = document.getElementById('memory-content');
  el.innerHTML = data.memories.map(m => `
    <div class="card" style="margin-bottom:8px">
      <div style="font-size:14px">${m.content.slice(0, 120)}</div>
      <div style="font-size:11px;color:var(--txt3);margin-top:4px">${m.created}</div>
    </div>`).join('');
}

// ── 进化 ──
async function loadEvolution() {
  const data = await api('/api/evolution');
  const el = document.getElementById('evolution-content');
  // 阶段
  const stages = [
    { icon: '🌱', name: '初始', pct: 20, color: 'var(--txt3)' },
    { icon: '🌿', name: '学习中', pct: 50, color: 'var(--warning)' },
    { icon: '🌳', name: '成长期', pct: 70, color: 'var(--teal)' },
    { icon: '⚡', name: '成熟体', pct: 90, color: 'var(--primary)' },
    { icon: '🧬', name: '进化体', pct: 100, color: 'var(--purple)' },
  ];
  let html = '<div style="display:grid;grid-template-columns:repeat(5,1fr);gap:8px;margin-bottom:24px">';
  for (const s of stages) {
    html += `<div class="card" style="text-align:center">
      <div style="font-size:32px">${s.icon}</div>
      <div style="font-weight:600;color:${s.color}">${s.name}</div>
      <div style="font-size:12px;color:var(--txt3)">${s.pct}%</div>
    </div>`;
  }
  html += '</div>';
  html += '<h3 style="margin-bottom:8px">📋 进化时间线</h3>';
  if (!data.events.length) {
    html += '<div style="text-align:center;padding:40px;color:var(--txt3)">暂无进化记录<br><small>对话越多，进化越快</small></div>';
  } else {
    html += data.events.map(e => `
      <div class="card" style="margin-bottom:8px">
        <div style="display:flex;align-items:center;gap:8px">
          <span>🧬</span><b>${e.event}</b>
          <span style="font-size:12px;color:var(--txt3);margin-left:auto">${e.ts}</span>
        </div>
        <div style="font-size:13px;color:var(--txt2);margin-top:4px">${e.detail || ''}</div>
      </div>`).join('');
  }
  el.innerHTML = html;
}

// ── 语音 ──
async function loadVoice() {
  const data = await api('/api/voice');
  const el = document.getElementById('voice-content');
  let html = `<div class="card" style="margin-bottom:16px">
    <b>🎤 TTS 引擎:</b> ${data.engine} | ${data.available ? '✅ 可用' : '❌ 未安装'}
    <p style="font-size:12px;color:var(--txt2);margin-top:4px">推荐: pip install edge-tts</p>
  </div>`;
  html += `<div class="card" style="margin-bottom:16px">
    <b>🧪 测试</b>
    <div style="display:flex;gap:8px;margin-top:8px">
      <input type="text" id="voice-test" value="你好，我是 Nexus Agent" style="flex:1">
      <button class="btn btn-primary" onclick="testVoice()">🔊 朗读</button>
    </div>
  </div>`;
  if (data.voices.length) {
    html += '<h3 style="margin:16px 0 8px">🎵 可用声音</h3>';
    html += data.voices.map(v => `<div class="card" style="margin-bottom:4px">
      <div style="display:flex;justify-content:space-between">
        <b>${v.name}</b><span style="font-size:12px;color:var(--txt3)">${v.lang}</span>
      </div>
    </div>`).join('');
  }
  el.innerHTML = html;
}

async function testVoice() {
  const text = document.getElementById('voice-test').value;
  await api('/api/voice/speak', 'POST', { text });
}

// ── 终端 ──
document.addEventListener('DOMContentLoaded', () => {
  const ti = document.getElementById('terminal-input');
  if (ti) ti.addEventListener('keydown', e => { if (e.key === 'Enter') runCmd(); });
});
async function runCmd() {
  const input = document.getElementById('terminal-input');
  const cmd = input.value.trim();
  if (!cmd) return;
  input.value = '';
  const output = document.getElementById('terminal-output');
  output.textContent += `\n❯ ${cmd}\n`;
  if (cmd === 'clear') { output.textContent = ''; return; }
  const r = await api('/api/tools/call', 'POST', { tool: 'execute_code', params: { code: cmd, lang: 'bash' } });
  output.textContent += (r.result || '无输出') + '\n';
  output.scrollTop = output.scrollHeight;
}

// ── 设置 ──
async function loadSettings() {
  const data = await api('/api/config');
  const stats = await api('/api/stats');
  const el = document.getElementById('settings-content');
  let html = `
    <div class="card" style="margin-bottom:16px">
      <h3>🤖 当前配置</h3>
      <p style="margin-top:8px">提供商: <b>${stats.provider || '未配置'}</b></p>
      <p>模型: <b>${stats.model || '未配置'}</b></p>
    </div>
    <div class="card" style="margin-bottom:16px">
      <h3>📊 运行统计</h3>
      <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-top:12px">
        <div><b>${stats.memories}</b><br><small>记忆</small></div>
        <div><b>${stats.conversations}</b><br><small>对话</small></div>
        <div><b>${stats.skills_file + stats.auto_skills}</b><br><small>技能</small></div>
        <div><b>${stats.total_tokens}</b><br><small>Tokens</small></div>
      </div>
    </div>
    <div class="card" style="margin-bottom:16px">
      <h3>🧠 记忆设置</h3>
      <div style="margin-top:8px">
        <label style="display:flex;justify-content:space-between;align-items:center">
          自动学习
          <label class="toggle"><input type="checkbox" checked><span class="slider"></span></label>
        </label>
      </div>
    </div>
    <div class="card">
      <h3>🔒 安全</h3>
      <div style="margin-top:8px">
        <label style="display:flex;justify-content:space-between;align-items:center">
          代码沙箱 <label class="toggle"><input type="checkbox" checked><span class="slider"></span></label>
        </label>
        <label style="display:flex;justify-content:space-between;align-items:center;margin-top:8px">
          注入防护 <label class="toggle"><input type="checkbox" checked><span class="slider"></span></label>
        </label>
      </div>
    </div>`;
  el.innerHTML = html;
}

// ── 头部模型更新 ──
async function updateHeaderModel() {
  const data = await api('/api/config');
  const cfg = data.config;
  const el = document.getElementById('chat-model');
  if (cfg.active_provider && cfg.active_model) {
    el.textContent = `${cfg.active_provider} / ${cfg.active_model}`;
  } else {
    el.textContent = '⚠️ 未配置';
  }
}

// ── 初始化 ──
document.addEventListener('DOMContentLoaded', async () => {
  const data = await api('/api/config');
  if (data.config.first_run || !data.configured) {
    showSetupWizard();
  } else {
    newSession();
  }
  updateHeaderModel();
});

// ── 首次设置向导 ──
async function showSetupWizard() {
  const data = await api('/api/providers');
  const overlay = document.getElementById('wizard-overlay');
  overlay.style.display = 'flex';
  const content = document.getElementById('wizard-content');

  // 步骤1: 选择提供商
  let grid = '';
  for (const [region, label] of [['cn', '🇨🇳 国内（无需翻墙）'], ['local', '💻 本地'], ['intl', '🌍 国际']]) {
    const ps = Object.entries(data.providers).filter(([, p]) => p.region === region);
    if (!ps.length) continue;
    grid += `<h4 style="grid-column:1/-1;margin:12px 0 4px">${label}</h4>`;
    for (const [id, p] of ps) {
      grid += `<div class="wizard-card" onclick="wizSelect('${id}', this)">
        <div class="wc-icon">${p.icon}</div>
        <div class="wc-name">${p.name}</div>
        <div class="wc-desc">${p.desc}</div>
        ${p.free ? '<span class="wc-free">免费</span>' : ''}
      </div>`;
    }
  }

  content.innerHTML = `<div class="wizard-step">
    <div style="font-size:48px">⚡</div>
    <h2>欢迎使用 Nexus Agent</h2>
    <p>通用 AI 智能体 · 融合 OpenClaw × Hermes Agent</p>
    <p style="font-size:14px">选择一个 AI 提供商开始：</p>
    <div class="wizard-grid">${grid}</div>
    <div id="wiz-selected" style="margin-top:16px;font-size:13px;color:var(--primary)"></div>
  </div>`;
}

let wizPid = null;
function wizSelect(pid, el) {
  document.querySelectorAll('.wizard-card').forEach(c => c.classList.remove('selected'));
  el.classList.add('selected');
  wizPid = pid;
  document.getElementById('wiz-selected').innerHTML = `已选择: ${pid} <button class="btn btn-primary btn-sm" onclick="wizNext()">下一步 →</button>`;
}

async function wizNext() {
  if (!wizPid) return;
  const data = await api('/api/providers');
  const p = data.providers[wizPid];
  showWizard(wizPid, p);
  // 标记已配置
  await api('/api/config', 'POST', { first_run: false });
}
