"""
Nexus v2.0 — 会话管理器
多会话支持，类似 OpenClaw 的 session 系统
"""

import uuid
from datetime import datetime


class Session:
    """单个会话"""

    def __init__(self, name: str = None):
        self.id = str(uuid.uuid4())[:8]
        self.name = name or f"会话 {self.id}"
        self.created = datetime.now().isoformat(timespec="seconds")
        self.messages: list = []
        self.model = ""
        self.total_tokens = 0
        self.tags: list = []

    def add(self, role: str, content: str, tokens: int = 0, model: str = ""):
        self.messages.append({
            "role": role, "content": content,
            "tokens": tokens, "model": model,
            "ts": datetime.now().isoformat(timespec="seconds"),
        })
        self.total_tokens += tokens
        if model:
            self.model = model

    @property
    def message_count(self):
        return len(self.messages)

    @property
    def last_message(self):
        return self.messages[-1]["content"][:80] if self.messages else ""

    def get_context(self, max_messages: int = 20) -> list:
        """获取上下文消息列表"""
        msgs = self.messages[-max_messages:]
        return [{"role": m["role"], "content": m["content"]} for m in msgs]


class SessionManager:
    """会话管理器"""

    def __init__(self, memory):
        self.memory = memory
        self.sessions: dict[str, Session] = {}
        self._active_id: str = None

    def create(self, name: str = None) -> Session:
        """创建新会话"""
        session = Session(name)
        self.sessions[session.id] = session
        self._active_id = session.id
        return session

    @property
    def active(self) -> Session:
        """当前活跃会话"""
        if self._active_id and self._active_id in self.sessions:
            return self.sessions[self._active_id]
        return self.create()

    def switch(self, session_id: str):
        """切换会话"""
        if session_id in self.sessions:
            self._active_id = session_id

    def list_all(self) -> list:
        """列出所有会话"""
        return [
            {"id": s.id, "name": s.name, "msgs": s.message_count,
             "tokens": s.total_tokens, "model": s.model, "created": s.created,
             "last": s.last_message}
            for s in sorted(self.sessions.values(),
                          key=lambda x: x.created, reverse=True)
        ]

    def delete(self, session_id: str):
        """删除会话"""
        self.sessions.pop(session_id, None)
        if self._active_id == session_id:
            self._active_id = None

    def rename(self, session_id: str, name: str):
        """重命名会话"""
        session = self.sessions.get(session_id)
        if session:
            session.name = name

    def export_session(self, session_id: str) -> str:
        """导出会话为文本"""
        session = self.sessions.get(session_id)
        if not session:
            return ""
        lines = [f"# {session.name}", f"创建时间: {session.created}", ""]
        for msg in session.messages:
            role = "👤 用户" if msg["role"] == "user" else "🤖 AI"
            lines.append(f"**{role}** ({msg['ts']})")
            lines.append(msg["content"])
            lines.append("")
        return "\n".join(lines)
