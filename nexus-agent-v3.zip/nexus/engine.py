"""
Nexus v2.0 — 核心引擎（完整版）
融合 OpenClaw × Hermes Agent 全部核心能力
"""

import json
import re
from datetime import datetime
from nexus.config import Config
from nexus.memory import Memory
from nexus.skills import SkillManager
from nexus.mcp import MCPClient
from nexus.session import SessionManager
from nexus.gateway import MessageGateway
from nexus.voice import VoiceEngine
from nexus.subagent import SubAgentManager
from nexus.heartbeat import Heartbeat, get_preset_checks
from nexus import ai_client, tools


class Engine:
    """Nexus 核心引擎 — 超级智能体"""

    def __init__(self, base_dir: str = None):
        self.config = Config(base_dir)
        base = str(self.config.base)

        # ── 子系统 ──
        self.memory = Memory(base)
        self.skills = SkillManager(base)
        self.mcp = MCPClient()
        self.sessions = SessionManager(self.memory)
        self.gateway = MessageGateway(base)
        self.voice = VoiceEngine()
        self.subagents = SubAgentManager(self)
        self.heartbeat = Heartbeat(self)

        self.session = datetime.now().strftime("s%Y%m%d_%H%M%S")
        self._history = []
        self._callbacks = {}

        # 注册心跳
        for check in get_preset_checks(self):
            self.heartbeat.on_check(check["name"], check["fn"])

        # 加载 MCP
        mcp_cfg = self.config.get("mcp_servers", {})
        from nexus.mcp import PRESET_MCP_SERVERS
        for sid, scfg in {**PRESET_MCP_SERVERS, **mcp_cfg}.items():
            if scfg.get("enabled"):
                self.mcp.add_server(sid, scfg["command"], scfg.get("args", []),
                                   scfg.get("env"))

    def on(self, event: str, callback):
        self._callbacks[event] = callback

    def _emit(self, event: str, data=None):
        cb = self._callbacks.get(event)
        if cb:
            cb(data)

    @property
    def is_configured(self) -> bool:
        pid = self.config.data.get("active_provider", "")
        if not pid:
            return False
        p = self.config.data.get("providers", {}).get(pid, {})
        if p.get("needs_key", True) and not p.get("api_key"):
            return False
        return bool(p.get("base_url"))

    def get_provider_config(self) -> dict:
        pid = self.config.data.get("active_provider", "")
        if not pid:
            return {}
        p = self.config.data.get("providers", {}).get(pid, {})
        from nexus.providers import PROVIDERS
        base = PROVIDERS.get(pid, {})
        return {**base, **p}

    def chat(self, user_msg: str, callback=None) -> dict:
        """
        完整智能体循环：
        1. 检索记忆 2. 检索技能 3. 构建上下文
        4. 调用 AI 5. 检测工具 6. 执行工具
        7. 自动学习 8. 保存记忆
        """
        self._emit("thinking", {"message": user_msg})

        # 记忆
        memories = self.memory.recall(user_msg, limit=3)
        mem_ctx = ""
        if memories:
            mem_ctx = "\n".join(f"[记忆] {m['content'][:150]}" for m in memories)

        # 技能
        relevant_skills = self.skills.find_relevant(user_msg)

        # 保存用户消息
        self.memory.save_msg(self.session, "user", user_msg)
        self._history.append({"role": "user", "content": user_msg})

        max_ctx = self.config.get("memory.max_context", 20)
        if len(self._history) > max_ctx:
            self._history = self._history[-max_ctx:]

        # 构建消息
        provider = self.get_provider_config()
        model = self.config.data.get("active_model") or provider.get("default", "")

        sys_parts = [ai_client.SYSTEM_PROMPT]
        if mem_ctx:
            sys_parts.append(f"\n相关记忆：\n{mem_ctx}")

        # 技能上下文
        skill_ctx = self.skills.get_context(max_chars=1500)
        if skill_ctx:
            sys_parts.append(skill_ctx)

        # 相关技能高亮
        if relevant_skills:
            highlights = [f"- {s.name}: {s.description[:60]}" for s in relevant_skills]
            sys_parts.append(f"\n与当前问题最相关的技能：\n" + "\n".join(highlights))

        # 工具列表
        tool_lines = ["\n## 可用工具"]
        for k, v in tools.TOOLS.items():
            params = ", ".join(v["params"])
            tool_lines.append(f"- {v['icon']} {v['name']} (`{k}`): {v['desc']}  参数: `{params}`")
        sys_parts.append("\n".join(tool_lines))

        # MCP 工具
        mcp_ctx = self.mcp.get_tools_prompt()
        if mcp_ctx:
            sys_parts.append(mcp_ctx)

        messages = [{"role": "system", "content": "\n".join(sys_parts)}]
        messages.extend(self._history)

        # 调用 AI
        self._emit("responding", {})
        result = ai_client.chat(messages, provider, model)

        if result["error"]:
            error_msg = f"⚠️ {result['error']}"
            self.memory.save_msg(self.session, "assistant", error_msg, model)
            self._history.append({"role": "assistant", "content": error_msg})
            return {"text": error_msg, "model": model, "tokens": 0,
                    "learned": False, "tool_used": False, "error": True}

        reply = result["text"]
        tokens = result["tokens"]

        # 工具调用检测与执行
        tool_result = self._try_tool_call(reply)
        if tool_result:
            tool_msg = f"[工具执行结果]\n{tool_result}"
            self._history.append({"role": "assistant", "content": reply})
            self._history.append({"role": "user", "content": tool_msg})

            messages2 = [{"role": "system", "content": "\n".join(sys_parts)}]
            messages2.extend(self._history)
            result2 = ai_client.chat(messages2, provider, model)
            if not result2["error"]:
                reply = result2["text"]
                tokens += result2["tokens"]

        # 保存
        self.memory.save_msg(self.session, "assistant", reply, model, tokens)
        self._history.append({"role": "assistant", "content": reply})

        # 自动学习
        learned = False
        if self.config.get("memory.auto_learn", True):
            if len(user_msg) > 15 and len(reply) > 50:
                self.memory.auto_learn(user_msg, reply, True)
                learned = True

        # 重要记忆
        if any(kw in user_msg.lower() for kw in ["记住", "remember", "重要"]):
            self.memory.remember(user_msg, "important", 0.9)

        # 笔记检测
        if any(kw in user_msg.lower() for kw in ["笔记", "note", "记下"]):
            self.memory.add_note(f"笔记 {datetime.now().strftime('%H:%M')}", user_msg)

        return {
            "text": reply, "model": model, "tokens": tokens,
            "learned": learned, "tool_used": tool_result is not None,
            "memories_used": len(memories), "error": False,
        }

    def _try_tool_call(self, text: str):
        """检测并执行工具调用（内置 + MCP）"""
        tool_call = None

        block = re.search(r'```json\s*(\{[^`]+\})\s*```', text, re.DOTALL)
        if block:
            tool_call = self._parse_json(block.group(1))

        if not tool_call:
            block = re.search(r'```tool\s*(\{[^`]+\})\s*```', text, re.DOTALL)
            if block:
                tool_call = self._parse_json(block.group(1))

        if not tool_call:
            for line in text.split('\n'):
                line = line.strip()
                if line.startswith('{') and line.endswith('}') and '"tool"' in line:
                    tool_call = self._parse_json(line)
                    if tool_call:
                        break

        if not tool_call:
            pattern = r'\{\s*"tool"\s*:\s*"([^"]+)"\s*,\s*"params"\s*:\s*(\{[^}]*\})\s*\}'
            match = re.search(pattern, text, re.DOTALL)
            if match:
                try:
                    tool_call = {"tool": match.group(1), "params": json.loads(match.group(2))}
                except Exception:
                    pass

        if not tool_call:
            return None

        tool_name = tool_call.get("tool", "")
        params = tool_call.get("params", {})

        if tool_name in tools.TOOLS:
            return tools.call_tool(tool_name, **params)

        server_name, mcp_tool = self.mcp.find_tool(tool_name)
        if server_name:
            return self.mcp.call_tool(server_name, tool_name, params)

        return f"⚠️ 未知工具: {tool_name}"

    def _parse_json(self, s: str) -> dict:
        try:
            d = json.loads(s)
            if "tool" in d:
                return d
        except Exception:
            pass
        return None

    def new_session(self):
        self._history = []
        self.session = datetime.now().strftime("s%Y%m%d_%H%M%S")

    def get_stats(self) -> dict:
        stats = self.memory.stats()
        stats["session"] = self.session
        stats["model"] = self.config.data.get("active_model", "未配置")
        stats["provider"] = self.config.data.get("active_provider", "未配置")
        stats["skills_file"] = len(self.skills.skills)
        stats["mcp_servers"] = len(self.mcp.servers)
        stats["mcp_tools"] = len(self.mcp.list_tools())
        stats["channels"] = len(self.gateway.channels)
        stats["subagents"] = self.subagents.active_count()
        stats["voice"] = self.voice.available
        return stats

    def export_data(self, path: str):
        import shutil
        shutil.copytree(str(self.config.base), path, dirs_exist_ok=True)
