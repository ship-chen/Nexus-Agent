"""
Nexus v2.0 — 工具系统
内置可执行工具，Agent 可以实际调用
"""

import os
import subprocess
import json
import urllib.request
import urllib.parse
from pathlib import Path


def web_search(query: str, max_results: int = 5) -> str:
    """网页搜索（DuckDuckGo，无需 API Key）"""
    try:
        url = f"https://html.duckduckgo.com/html/?q={urllib.parse.quote(query)}"
        req = urllib.request.Request(url, headers={
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120"
        })
        with urllib.request.urlopen(req, timeout=15) as r:
            html = r.read().decode("utf-8", errors="replace")

        # 简单提取结果
        results = []
        import re
        # 提取标题和链接
        for m in re.finditer(r'<a[^>]+class="result__a"[^>]*href="([^"]*)"[^>]*>(.*?)</a>', html):
            link = m.group(1)
            title = re.sub(r'<[^>]+>', '', m.group(2)).strip()
            if title and link:
                results.append(f"• {title}\n  {link}")
            if len(results) >= max_results:
                break

        if results:
            return f"🔍 搜索「{query}」的结果：\n\n" + "\n\n".join(results)
        return f"🔍 搜索「{query}」未找到结果"
    except Exception as e:
        return f"⚠️ 搜索失败: {e}"


def execute_code(code: str, lang: str = "python", timeout: int = 30) -> str:
    """在沙箱中执行代码"""
    try:
        if lang == "python":
            result = subprocess.run(
                ["python3", "-c", code],
                capture_output=True, text=True, timeout=timeout,
                env={**os.environ, "PYTHONIOENCODING": "utf-8"}
            )
        elif lang in ("sh", "bash", "shell"):
            result = subprocess.run(
                ["bash", "-c", code],
                capture_output=True, text=True, timeout=timeout
            )
        else:
            return f"⚠️ 不支持的语言: {lang}"

        output = ""
        if result.stdout:
            output += result.stdout
        if result.stderr:
            output += f"\n[stderr]\n{result.stderr}"
        if result.returncode != 0:
            output += f"\n[exit code: {result.returncode}]"
        return output.strip() or "(无输出)"
    except subprocess.TimeoutExpired:
        return f"⏰ 执行超时（{timeout}秒）"
    except Exception as e:
        return f"❌ 执行错误: {e}"


def read_file(path: str, max_lines: int = 200) -> str:
    """读取文件内容"""
    try:
        p = Path(path).expanduser()
        if not p.exists():
            return f"⚠️ 文件不存在: {path}"
        if p.stat().st_size > 1024 * 1024:  # 1MB 限制
            return f"⚠️ 文件过大（{p.stat().st_size / 1024 / 1024:.1f}MB），跳过"
        with open(p, "r", encoding="utf-8", errors="replace") as f:
            lines = f.readlines()[:max_lines]
        content = "".join(lines)
        if len(lines) == max_lines:
            content += f"\n... (截断，共 {sum(1 for _ in open(p))} 行)"
        return content
    except Exception as e:
        return f"⚠️ 读取失败: {e}"


def write_file(path: str, content: str) -> str:
    """写入文件"""
    try:
        p = Path(path).expanduser()
        p.parent.mkdir(parents=True, exist_ok=True)
        with open(p, "w", encoding="utf-8") as f:
            f.write(content)
        return f"✅ 已写入 {p}（{len(content)} 字符）"
    except Exception as e:
        return f"⚠️ 写入失败: {e}"


def list_dir(path: str = ".") -> str:
    """列出目录内容"""
    try:
        p = Path(path).expanduser()
        if not p.exists():
            return f"⚠️ 目录不存在: {path}"
        items = []
        for item in sorted(p.iterdir()):
            if item.is_dir():
                items.append(f"📁 {item.name}/")
            else:
                size = item.stat().st_size
                if size < 1024:
                    s = f"{size}B"
                elif size < 1024 * 1024:
                    s = f"{size / 1024:.1f}KB"
                else:
                    s = f"{size / 1024 / 1024:.1f}MB"
                items.append(f"📄 {item.name}  ({s})")
        return "\n".join(items) if items else "(空目录)"
    except Exception as e:
        return f"⚠️ 列出失败: {e}"


def get_system_info() -> str:
    """获取系统信息"""
    import platform
    info = [
        f"系统: {platform.system()} {platform.release()}",
        f"机器: {platform.machine()}",
        f"Python: {platform.python_version()}",
        f"工作目录: {os.getcwd()}",
    ]
    try:
        import shutil
        total, used, free = shutil.disk_usage("/")
        info.append(f"磁盘: {used / 1024**3:.1f}GB / {total / 1024**3:.1f}GB")
    except Exception:
        pass
    return "\n".join(info)


def web_fetch(url: str, max_chars: int = 3000) -> str:
    """抓取网页内容"""
    try:
        req = urllib.request.Request(url, headers={
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120"
        })
        with urllib.request.urlopen(req, timeout=15) as r:
            html = r.read().decode("utf-8", errors="replace")

        # 简单去标签
        import re
        text = re.sub(r'<script[^>]*>.*?</script>', '', html, flags=re.DOTALL)
        text = re.sub(r'<style[^>]*>.*?</style>', '', text, flags=re.DOTALL)
        text = re.sub(r'<[^>]+>', ' ', text)
        text = re.sub(r'\s+', ' ', text).strip()
        return text[:max_chars] + ("..." if len(text) > max_chars else "")
    except Exception as e:
        return f"⚠️ 抓取失败: {e}"


# ── 工具注册表 ──
TOOLS = {
    "web_search": {
        "name": "网页搜索",
        "desc": "使用 DuckDuckGo 搜索互联网",
        "icon": "🔍",
        "fn": web_search,
        "params": ["query"],
    },
    "execute_code": {
        "name": "执行代码",
        "desc": "在沙箱中运行 Python/Shell 代码",
        "icon": "💻",
        "fn": execute_code,
        "params": ["code", "lang"],
    },
    "read_file": {
        "name": "读取文件",
        "desc": "读取本地文件内容",
        "icon": "📖",
        "fn": read_file,
        "params": ["path"],
    },
    "write_file": {
        "name": "写入文件",
        "desc": "写入内容到本地文件",
        "icon": "✏️",
        "fn": write_file,
        "params": ["path", "content"],
    },
    "list_dir": {
        "name": "列出目录",
        "desc": "查看目录中的文件和子目录",
        "icon": "📁",
        "fn": list_dir,
        "params": ["path"],
    },
    "web_fetch": {
        "name": "抓取网页",
        "desc": "获取指定 URL 的网页内容",
        "icon": "🌐",
        "fn": web_fetch,
        "params": ["url"],
    },
    "system_info": {
        "name": "系统信息",
        "desc": "获取当前系统环境信息",
        "icon": "ℹ️",
        "fn": get_system_info,
        "params": [],
    },
}


def call_tool(name: str, **kwargs) -> str:
    """调用指定工具"""
    tool = TOOLS.get(name)
    if not tool:
        return f"⚠️ 未知工具: {name}"
    try:
        return tool["fn"](**kwargs)
    except Exception as e:
        return f"⚠️ 工具执行失败: {e}"


def get_tools_prompt() -> str:
    """生成工具描述（注入系统提示）"""
    lines = ["你可以使用以下工具，在需要时调用："]
    for k, v in TOOLS.items():
        params = ", ".join(v["params"])
        lines.append(f"- {v['icon']} {v['name']} ({k}): {v['desc']}  参数: [{params}]")
    lines.append('\n调用格式（JSON）：\n{"tool": "工具名", "params": {"参数": "值"}}')
    return "\n".join(lines)
