"""
Nexus v2.0 — MCP 客户端
Model Context Protocol 支持
连接 MCP Server 获取额外工具
"""

import json
import subprocess
import threading
import os
from pathlib import Path


class MCPClient:
    """MCP 客户端 — 连接 MCP Server"""

    def __init__(self):
        self.servers: dict[str, MCPServer] = {}
        self._lock = threading.Lock()

    def add_server(self, name: str, command: str, args: list = None,
                   env: dict = None, cwd: str = None):
        """添加 MCP Server"""
        server = MCPServer(name, command, args or [], env, cwd)
        self.servers[name] = server
        return server

    def remove_server(self, name: str):
        """移除 MCP Server"""
        if name in self.servers:
            self.servers[name].stop()
            del self.servers[name]

    def connect_all(self):
        """连接所有服务器"""
        for name, server in self.servers.items():
            if not server.running:
                server.start()

    def disconnect_all(self):
        """断开所有服务器"""
        for server in self.servers.values():
            server.stop()

    def list_tools(self) -> list:
        """列出所有 MCP 工具"""
        tools = []
        for name, server in self.servers.items():
            if server.running:
                for tool in server.tools:
                    tools.append({
                        "server": name,
                        "name": tool["name"],
                        "desc": tool.get("description", ""),
                        "params": tool.get("inputSchema", {}),
                    })
        return tools

    def call_tool(self, server_name: str, tool_name: str, arguments: dict = None) -> str:
        """调用 MCP 工具"""
        server = self.servers.get(server_name)
        if not server or not server.running:
            return f"⚠️ MCP Server '{server_name}' 未连接"
        return server.call_tool(tool_name, arguments or {})

    def find_tool(self, tool_name: str):
        """查找工具属于哪个服务器"""
        for name, server in self.servers.items():
            if server.running:
                for tool in server.tools:
                    if tool["name"] == tool_name:
                        return name, tool
        return None, None

    def get_tools_prompt(self) -> str:
        """生成 MCP 工具描述（注入系统提示）"""
        tools = self.list_tools()
        if not tools:
            return ""
        lines = ["\n## MCP 工具（外部服务器）"]
        for t in tools:
            params = ""
            schema = t.get("params", {})
            if schema and "properties" in schema:
                params = ", ".join(schema["properties"].keys())
            lines.append(f"- `{t['name']}` ({t['server']}): {t['desc']}  参数: [{params}]")
        return "\n".join(lines)


class MCPServer:
    """单个 MCP Server 连接"""

    def __init__(self, name: str, command: str, args: list,
                 env: dict = None, cwd: str = None):
        self.name = name
        self.command = command
        self.args = args
        self.env = env or {}
        self.cwd = cwd
        self.running = False
        self.tools: list = []
        self._proc = None
        self._req_id = 0
        self._lock = threading.Lock()
        self._pending = {}

    def start(self):
        """启动 MCP Server"""
        try:
            full_env = {**os.environ, **self.env}
            self._proc = subprocess.Popen(
                [self.command] + self.args,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                env=full_env,
                cwd=self.cwd,
            )
            self.running = True

            # 初始化
            resp = self._send("initialize", {
                "protocolVersion": "2024-11-05",
                "capabilities": {},
                "clientInfo": {"name": "Nexus Agent", "version": "2.0.0"}
            })

            if resp and "result" in resp:
                # 通知已初始化
                self._notify("notifications/initialized", {})
                # 获取工具列表
                self._refresh_tools()
                return True

        except FileNotFoundError:
            pass
        except Exception:
            pass
        self.running = False
        return False

    def stop(self):
        """停止 MCP Server"""
        if self._proc:
            try:
                self._proc.terminate()
                self._proc.wait(timeout=5)
            except Exception:
                try:
                    self._proc.kill()
                except Exception:
                    pass
        self.running = False
        self.tools = []

    def call_tool(self, name: str, arguments: dict) -> str:
        """调用 MCP 工具"""
        resp = self._send("tools/call", {"name": name, "arguments": arguments})
        if not resp:
            return "⚠️ 工具调用失败：无响应"
        if "error" in resp:
            return f"⚠️ 工具错误: {resp['error'].get('message', 'unknown')}"
        result = resp.get("result", {})
        # 提取文本内容
        content = result.get("content", [])
        texts = []
        for item in content:
            if item.get("type") == "text":
                texts.append(item.get("text", ""))
        return "\n".join(texts) if texts else json.dumps(result, ensure_ascii=False)

    def _refresh_tools(self):
        """获取工具列表"""
        resp = self._send("tools/list", {})
        if resp and "result" in resp:
            self.tools = resp["result"].get("tools", [])

    def _send(self, method: str, params: dict) -> dict:
        """发送 JSON-RPC 请求"""
        if not self._proc or not self._proc.stdin:
            return None

        with self._lock:
            self._req_id += 1
            req = {
                "jsonrpc": "2.0",
                "id": self._req_id,
                "method": method,
                "params": params,
            }

            try:
                msg = json.dumps(req) + "\n"
                self._proc.stdin.write(msg.encode())
                self._proc.stdin.flush()

                # 读取响应
                line = self._proc.stdout.readline()
                if line:
                    return json.loads(line.decode().strip())
            except Exception:
                pass
            return None

    def _notify(self, method: str, params: dict):
        """发送通知（无响应）"""
        if not self._proc or not self._proc.stdin:
            return
        req = {"jsonrpc": "2.0", "method": method, "params": params}
        try:
            msg = json.dumps(req) + "\n"
            self._proc.stdin.write(msg.encode())
            self._proc.stdin.flush()
        except Exception:
            pass


# ── 预置 MCP Server 配置 ──

PRESET_MCP_SERVERS = {
    "filesystem": {
        "name": "文件系统",
        "desc": "增强文件操作能力",
        "command": "npx",
        "args": ["-y", "@modelcontextprotocol/server-filesystem", os.path.expanduser("~")],
        "enabled": False,
    },
    "brave-search": {
        "name": "Brave 搜索",
        "desc": "使用 Brave Search API 搜索",
        "command": "npx",
        "args": ["-y", "@modelcontextprotocol/server-brave-search"],
        "env_key": "BRAVE_API_KEY",
        "enabled": False,
    },
    "sqlite": {
        "name": "SQLite",
        "desc": "操作 SQLite 数据库",
        "command": "uvx",
        "args": ["mcp-server-sqlite", "--db-path", "nexus.db"],
        "enabled": False,
    },
    "puppeteer": {
        "name": "Puppeteer 浏览器",
        "desc": "浏览器自动化控制",
        "command": "npx",
        "args": ["-y", "@modelcontextprotocol/server-puppeteer"],
        "enabled": False,
    },
}
