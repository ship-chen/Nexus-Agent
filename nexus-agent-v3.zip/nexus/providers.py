"""
Nexus v2.0 — 提供商注册表
预置 18+ 国内外 AI 提供商，支持任意自定义
"""

PROVIDERS = {
    # ── 国内 ──
    "deepseek": {
        "name": "DeepSeek 深度求索", "icon": "🔮",
        "base_url": "https://api.deepseek.com/v1",
        "type": "openai", "needs_key": True, "region": "cn",
        "models": ["deepseek-chat", "deepseek-coder", "deepseek-reasoner"],
        "default": "deepseek-chat",
        "desc": "国产推理顶尖，性价比极高", "free": True,
    },
    "qwen": {
        "name": "通义千问 Qwen", "icon": "🌟",
        "base_url": "https://dashscope.aliyuncs.com/compatible-mode/v1",
        "type": "openai", "needs_key": True, "region": "cn",
        "models": ["qwen-turbo", "qwen-plus", "qwen-max", "qwen-long",
                   "qwen-vl-plus", "qwen-vl-max", "qwq-plus"],
        "default": "qwen-plus",
        "desc": "阿里旗舰，中文出色，多模态", "free": True,
    },
    "zhipu": {
        "name": "智谱 GLM", "icon": "🧠",
        "base_url": "https://open.bigmodel.cn/api/paas/v4",
        "type": "openai", "needs_key": True, "region": "cn",
        "models": ["glm-4", "glm-4-flash", "glm-4v", "glm-4-air",
                   "glm-4-airx", "glm-4-long", "codegeex-4"],
        "default": "glm-4-flash",
        "desc": "清华系，视觉理解强", "free": True,
    },
    "moonshot": {
        "name": "月之暗面 Kimi", "icon": "🌙",
        "base_url": "https://api.moonshot.cn/v1",
        "type": "openai", "needs_key": True, "region": "cn",
        "models": ["moonshot-v1-8k", "moonshot-v1-32k", "moonshot-v1-128k"],
        "default": "moonshot-v1-8k",
        "desc": "超长上下文，文档分析利器", "free": True,
    },
    "yi": {
        "name": "零一万物 Yi", "icon": "0️⃣",
        "base_url": "https://api.lingyiwanwu.com/v1",
        "type": "openai", "needs_key": True, "region": "cn",
        "models": ["yi-large", "yi-medium", "yi-spark", "yi-large-turbo",
                   "yi-vision", "yi-large-fc"],
        "default": "yi-large-turbo",
        "desc": "李开复团队，综合能力强", "free": True,
    },
    "baichuan": {
        "name": "百川 Baichuan", "icon": "🏔️",
        "base_url": "https://api.baichuan-ai.com/v1",
        "type": "openai", "needs_key": True, "region": "cn",
        "models": ["Baichuan4", "Baichuan3-Turbo", "Baichuan2-Turbo"],
        "default": "Baichuan4",
        "desc": "搜索增强，知识问答突出", "free": True,
    },
    "spark": {
        "name": "讯飞星火 Spark", "icon": "✨",
        "base_url": "https://spark-api-open.xf-yun.com/v1",
        "type": "openai", "needs_key": True, "region": "cn",
        "models": ["generalv3.5", "generalv3", "4.0Ultra"],
        "default": "generalv3.5",
        "desc": "科大讯飞，语音交互领先", "free": True,
    },
    "stepfun": {
        "name": "阶跃星辰 Step", "icon": "🚶",
        "base_url": "https://api.stepfun.com/v1",
        "type": "openai", "needs_key": True, "region": "cn",
        "models": ["step-1-8k", "step-1-32k", "step-1-128k", "step-1v-8k"],
        "default": "step-1-8k",
        "desc": "多模态，视频分析强", "free": True,
    },
    "minimax": {
        "name": "MiniMax", "icon": "Ⓜ️",
        "base_url": "https://api.minimax.chat/v1",
        "type": "openai", "needs_key": True, "region": "cn",
        "models": ["abab6.5-chat", "abab6.5s-chat", "abab5.5-chat"],
        "default": "abab6.5s-chat",
        "desc": "角色扮演和创意写作出色", "free": True,
    },
    "internlm": {
        "name": "书生浦语 InternLM", "icon": "📖",
        "base_url": "https://internlm-chat.intern-ai.org.cn/puyu/api/v1",
        "type": "openai", "needs_key": True, "region": "cn",
        "models": ["internlm2-latest", "internlm2-chat-latest"],
        "default": "internlm2-chat-latest",
        "desc": "上海AI实验室，学术级推理", "free": True,
    },

    # ── 国际 ──
    "openai": {
        "name": "OpenAI", "icon": "🟢",
        "base_url": "https://api.openai.com/v1",
        "type": "openai", "needs_key": True, "region": "intl",
        "models": ["gpt-4o", "gpt-4o-mini", "gpt-4-turbo", "gpt-4",
                   "gpt-3.5-turbo", "o1", "o1-mini"],
        "default": "gpt-4o",
        "desc": "全球最强通用模型", "free": False,
    },
    "anthropic": {
        "name": "Anthropic Claude", "icon": "🟠",
        "base_url": "https://api.anthropic.com",
        "type": "anthropic", "needs_key": True, "region": "intl",
        "models": ["claude-sonnet-4-20250514", "claude-3-5-haiku-20241022",
                   "claude-3-opus-20240229"],
        "default": "claude-sonnet-4-20250514",
        "desc": "代码与分析能力顶尖", "free": False,
    },
    "openrouter": {
        "name": "OpenRouter", "icon": "🔀",
        "base_url": "https://openrouter.ai/api/v1",
        "type": "openai", "needs_key": True, "region": "intl",
        "models": ["auto", "anthropic/claude-3.5-sonnet", "openai/gpt-4o",
                   "google/gemini-pro-1.5", "meta-llama/llama-3.1-405b-instruct",
                   "deepseek/deepseek-chat"],
        "default": "auto",
        "desc": "一个 Key 用所有模型", "free": True,
    },
    "groq": {
        "name": "Groq", "icon": "⚡",
        "base_url": "https://api.groq.com/openai/v1",
        "type": "openai", "needs_key": True, "region": "intl",
        "models": ["llama-3.1-70b-versatile", "llama-3.1-8b-instant",
                   "mixtral-8x7b-32768", "gemma2-9b-it"],
        "default": "llama-3.1-70b-versatile",
        "desc": "极速推理，免费额度慷慨", "free": True,
    },
    "together": {
        "name": "Together AI", "icon": "🤝",
        "base_url": "https://api.together.xyz/v1",
        "type": "openai", "needs_key": True, "region": "intl",
        "models": ["meta-llama/Meta-Llama-3.1-405B-Instruct-Turbo",
                   "meta-llama/Meta-Llama-3.1-70B-Instruct-Turbo",
                   "mistralai/Mixtral-8x22B-Instruct-v0.1"],
        "default": "meta-llama/Meta-Llama-3.1-70B-Instruct-Turbo",
        "desc": "开源模型聚合", "free": True,
    },

    # ── 本地 ──
    "ollama": {
        "name": "Ollama 本地", "icon": "🦙",
        "base_url": "http://localhost:11434",
        "type": "ollama", "needs_key": False, "region": "local",
        "models": ["llama3.1", "llama3", "mistral", "qwen2.5",
                   "deepseek-v2", "phi3", "gemma2", "codellama"],
        "default": "llama3.1",
        "desc": "本地运行，完全离线免费", "free": True,
    },
    "lmstudio": {
        "name": "LM Studio", "icon": "🖥️",
        "base_url": "http://localhost:1234/v1",
        "type": "openai", "needs_key": False, "region": "local",
        "models": ["local-model"],
        "default": "local-model",
        "desc": "图形化本地模型管理", "free": True,
    },
    "custom": {
        "name": "自定义提供商", "icon": "🔧",
        "base_url": "",
        "type": "openai", "needs_key": True, "region": "custom",
        "models": [],
        "default": "",
        "desc": "支持任意 OpenAI 兼容 API", "free": True,
    },
}

REGIONS = {
    "cn":    {"name": "🇨🇳 国内提供商", "desc": "无需翻墙，开箱即用"},
    "intl":  {"name": "🌍 国际提供商", "desc": "需代理或海外服务器"},
    "local": {"name": "💻 本地部署",   "desc": "完全离线，隐私无忧"},
    "custom":{"name": "🔧 自定义",     "desc": "接入你自己的 API"},
}

def get_by_region():
    g = {"cn": [], "intl": [], "local": [], "custom": []}
    for k, v in PROVIDERS.items():
        g[v.get("region", "custom")].append({**v, "id": k})
    return g
