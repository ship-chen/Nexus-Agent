"""
Nexus v2.0 — 心跳系统
OpenClaw 风格的主动检查机制
"""

import threading
import time
from datetime import datetime


class Heartbeat:
    """心跳系统 — 定期主动检查"""

    def __init__(self, engine, interval: int = 1800):  # 30 分钟
        self.engine = engine
        self.interval = interval
        self.running = False
        self._thread = None
        self._callbacks = []
        self._last_check = {}

    def on_check(self, name: str, fn):
        """注册检查项"""
        self._callbacks.append({"name": name, "fn": fn})

    def start(self):
        """启动心跳"""
        if self.running:
            return
        self.running = True
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()

    def stop(self):
        self.running = False

    def _loop(self):
        while self.running:
            self._beat()
            time.sleep(self.interval)

    def _beat(self):
        """单次心跳"""
        now = datetime.now()
        results = []
        for check in self._callbacks:
            try:
                result = check["fn"]()
                if result:
                    results.append(f"[{check['name']}] {result}")
            except Exception:
                pass

        if results:
            summary = "\n".join(results)
            self.engine.memory.remember(
                f"心跳检查 {now.strftime('%H:%M')}:\n{summary}",
                "heartbeat", 0.3
            )

    def beat_now(self):
        """立即执行一次心跳"""
        self._beat()


# ── 预置检查项 ──

def check_memory_stats(engine):
    """检查记忆统计"""
    stats = engine.memory.stats()
    if stats["memories"] > 1000:
        return f"记忆条目过多 ({stats['memories']})，建议清理"
    return None

def check_session_age(engine):
    """检查会话时长"""
    session = engine.session
    # 简单检查
    return None

def get_preset_checks(engine):
    """获取预置检查项"""
    return [
        {"name": "记忆", "fn": lambda: check_memory_stats(engine)},
    ]
